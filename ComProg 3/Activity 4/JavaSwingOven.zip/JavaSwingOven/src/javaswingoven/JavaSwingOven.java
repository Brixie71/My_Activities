
package javaswingoven;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent; 
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class JavaSwingOven extends JFrame{
    
    JPanel OvenBackground, ButtonsPanel, Microwave, Title;
    JButton one, two, three, four, five, six, seven, eight, nine, zero, Enter, Reset;
    JLabel Product, cooking;
    JTextField Input;
    
    public JavaSwingOven(){
        MainGUIComponents();
    }
    
    private void MainGUIComponents(){

        OvenBackground = new JPanel();
        ButtonsPanel = new JPanel();
        Microwave = new JPanel();
        Title = new JPanel();
        
        one = new JButton();
        two = new JButton();
        three = new JButton();
        four = new JButton();
        five = new JButton();
        six = new JButton();
        seven = new JButton();
        eight = new JButton();
        nine = new JButton();
        zero = new JButton();
        Enter = new JButton();
        Reset = new JButton();
        
        Product = new JLabel();
        cooking = new JLabel();
        
        Input = new JTextField();
           
        
        // JFrame Declaration
        final int FrameWidth  = 600;
        final int FrameHeight = 400;
        
        // JFrame Size.
        setSize(FrameWidth, FrameHeight);
        setMinimumSize(new java.awt.Dimension(FrameWidth, FrameHeight));
        
        // JFrame Decoration.
        setUndecorated(false);
        setOpacity(1.0f);
        setTitle("Panasonic : Microwave Oven - B121");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        pack();
        setLayout(new BorderLayout());
        
        
        // CENTER POPUP MAIN WINDOW.
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dimension.width / 2 - this.getWidth() / 2, dimension.height / 2 - this.getHeight() / 2);
        
        // Title (JPanel) Declarations.
        
        add(Title, BorderLayout.NORTH);
        Title.setBackground(new java.awt.Color(0, 0, 32));
        Title.setBorder(new javax.swing.border.EmptyBorder(5, 5, 5, 5));
        Title.setLayout(new BorderLayout());
        Title.setVisible(true);
        
        // Product (JLabel) Declarations.

            final int loginTitleLocationX   = 0;
            final int loginTitleLocationY   = 0;
            final int loginTitleWidth       = 150;
            final int loginTitleHeight      = 30;

            Product.setBounds(loginTitleLocationX, loginTitleLocationY, loginTitleWidth, loginTitleHeight);
            Title.add(Product);
            Product.setForeground(new java.awt.Color(255,255,255));
            Product.setFont(new java.awt.Font("Times New Roman", Font.PLAIN, 25));
            Product.setText("PANASONIC : B121 Microwave Oven");
            Product.setHorizontalAlignment(SwingConstants.LEADING);
            Product.setVisible(true);
        
        
        // Oven Background (JPanel) Declarations.
        
        add(OvenBackground, BorderLayout.CENTER);
        OvenBackground.setBackground(new java.awt.Color(0, 0, 32));
        OvenBackground.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 200, 0), 2, false));
        OvenBackground.setLayout(new GridLayout(1,2,3,3));
        OvenBackground.setVisible(true);
        
        // Microwave (JPanel) Declarations.
        OvenBackground.add(Microwave);
        Microwave.setBackground(new java.awt.Color(255, 255, 255));
        Microwave.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, false));
        Microwave.setLayout(new GridLayout(1,1,0,0));
        Microwave.setVisible(true);
            
        Microwave.add(cooking, BorderLayout.NORTH);
        cooking.setBackground(new java.awt.Color(255, 255, 255));
        cooking.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, false));
        cooking.setLayout(new GridLayout(1,1,0,0));
        cooking.setVisible(true);

        ImageIcon findPersonelPicture = new ImageIcon("src\\Resources\\Cookies.gif");
        Image importPersonelPicture = findPersonelPicture.getImage();
        //Image scalePersonelPicture = importPersonelPicture.getScaledInstance(cooking.getWidth(), cooking.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledPersonelPicture = new ImageIcon(importPersonelPicture);
        cooking.setIcon(scaledPersonelPicture);
        
        
        // Buttons Panel (JPanel) Declarations.
        OvenBackground.add(ButtonsPanel, BorderLayout.EAST);
        ButtonsPanel.setBackground(new java.awt.Color(0, 0, 32));
        ButtonsPanel.setBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0));
        ButtonsPanel.setLayout(new GridLayout(4,3,0,0));
        ButtonsPanel.setVisible(true);
        
            // Button 1 (JButtons) Declarations.
            ButtonsPanel.add(one);
            one.setBackground(new java.awt.Color(248, 249, 250));
            one.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            one.setFocusPainted(false);
            one.setHorizontalAlignment(SwingConstants.CENTER);
            one.setOpaque(false);
            one.setForeground(new java.awt.Color(0,0,0));
            one.setText("1");
            one.setVisible(true);

            one.setContentAreaFilled(true);
            one.setBorderPainted(false);
            one.setIconTextGap(-2);

            one.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                one.setBackground(new java.awt.Color(0, 0, 0));
                one.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                one.setBackground(new java.awt.Color(248, 249, 250));
                one.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                one.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                one.setBackground(new java.awt.Color(248, 249, 250));
                one.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 2 (JButtons) Declarations.
            ButtonsPanel.add(two);
            two.setBackground(new java.awt.Color(248, 249, 250));
            two.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            two.setFocusPainted(false);
            two.setHorizontalAlignment(SwingConstants.CENTER);
            two.setOpaque(false);
            two.setForeground(new java.awt.Color(0,0,0));
            two.setText("2");
            two.setVisible(true);

            two.setContentAreaFilled(true);
            two.setBorderPainted(false);
            two.setIconTextGap(-2);

            two.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                two.setBackground(new java.awt.Color(0, 0, 0));
                two.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                two.setBackground(new java.awt.Color(248, 249, 250));
                two.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                two.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                two.setBackground(new java.awt.Color(248, 249, 250));
                two.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 3 (JButtons) Declarations.
            ButtonsPanel.add(three);
            three.setBackground(new java.awt.Color(248, 249, 250));
            three.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            three.setFocusPainted(false);
            three.setHorizontalAlignment(SwingConstants.CENTER);
            three.setOpaque(false);
            three.setForeground(new java.awt.Color(0,0,0));
            three.setText("3");
            three.setVisible(true);

            three.setContentAreaFilled(true);
            three.setBorderPainted(false);
            three.setIconTextGap(-2);

            three.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                three.setBackground(new java.awt.Color(0, 0, 0));
                three.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                three.setBackground(new java.awt.Color(248, 249, 250));
                three.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                three.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                three.setBackground(new java.awt.Color(248, 249, 250));
                three.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 4 (JButtons) Declarations.
            ButtonsPanel.add(four);
            four.setBackground(new java.awt.Color(248, 249, 250));
            four.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            four.setFocusPainted(false);
            four.setHorizontalAlignment(SwingConstants.CENTER);
            four.setOpaque(false);
            four.setForeground(new java.awt.Color(0,0,0));
            four.setText("4");
            four.setVisible(true);

            four.setContentAreaFilled(true);
            four.setBorderPainted(false);
            four.setIconTextGap(-2);

            four.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                four.setBackground(new java.awt.Color(0, 0, 0));
                four.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                four.setBackground(new java.awt.Color(248, 249, 250));
                four.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                four.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                four.setBackground(new java.awt.Color(248, 249, 250));
                four.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 5 (JButtons) Declarations.
            ButtonsPanel.add(five);
            five.setBackground(new java.awt.Color(248, 249, 250));
            five.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            five.setFocusPainted(false);
            five.setHorizontalAlignment(SwingConstants.CENTER);
            five.setOpaque(false);
            five.setForeground(new java.awt.Color(0,0,0));
            five.setText("5");
            five.setVisible(true);

            five.setContentAreaFilled(true);
            five.setBorderPainted(false);
            five.setIconTextGap(-2);

            five.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                five.setBackground(new java.awt.Color(0, 0, 0));
                five.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                five.setBackground(new java.awt.Color(248, 249, 250));
                five.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                five.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                five.setBackground(new java.awt.Color(248, 249, 250));
                five.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 6 (JButtons) Declarations.
            ButtonsPanel.add(six);
            six.setBackground(new java.awt.Color(248, 249, 250));
            six.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            six.setFocusPainted(false);
            six.setHorizontalAlignment(SwingConstants.CENTER);
            six.setOpaque(false);
            six.setForeground(new java.awt.Color(0,0,0));
            six.setText("6");
            six.setVisible(true);

            six.setContentAreaFilled(true);
            six.setBorderPainted(false);
            six.setIconTextGap(-2);

            six.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                six.setBackground(new java.awt.Color(0, 0, 0));
                six.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                six.setBackground(new java.awt.Color(248, 249, 250));
                six.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                six.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                six.setBackground(new java.awt.Color(248, 249, 250));
                six.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 7 (JButtons) Declarations.
            ButtonsPanel.add(seven);
            seven.setBackground(new java.awt.Color(248, 249, 250));
            seven.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            seven.setFocusPainted(false);
            seven.setHorizontalAlignment(SwingConstants.CENTER);
            seven.setOpaque(false);
            seven.setForeground(new java.awt.Color(0,0,0));
            seven.setText("7");
            seven.setVisible(true);

            seven.setContentAreaFilled(true);
            seven.setBorderPainted(false);
            seven.setIconTextGap(-2);

            seven.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                seven.setBackground(new java.awt.Color(0, 0, 0));
                seven.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                seven.setBackground(new java.awt.Color(248, 249, 250));
                seven.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                seven.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                seven.setBackground(new java.awt.Color(248, 249, 250));
                seven.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 8 (JButtons) Declarations.
            ButtonsPanel.add(eight);
            eight.setBackground(new java.awt.Color(248, 249, 250));
            eight.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            eight.setFocusPainted(false);
            eight.setHorizontalAlignment(SwingConstants.CENTER);
            eight.setOpaque(false);
            eight.setForeground(new java.awt.Color(0,0,0));
            eight.setText("8");
            eight.setVisible(true);

            eight.setContentAreaFilled(true);
            eight.setBorderPainted(false);
            eight.setIconTextGap(-2);

            eight.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                eight.setBackground(new java.awt.Color(0, 0, 0));
                eight.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                eight.setBackground(new java.awt.Color(248, 249, 250));
                eight.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                eight.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                eight.setBackground(new java.awt.Color(248, 249, 250));
                eight.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 9 (JButtons) Declarations.
            ButtonsPanel.add(nine);
            nine.setBackground(new java.awt.Color(248, 249, 250));
            nine.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            nine.setFocusPainted(false);
            nine.setHorizontalAlignment(SwingConstants.CENTER);
            nine.setOpaque(false);
            nine.setForeground(new java.awt.Color(0,0,0));
            nine.setText("9");
            nine.setVisible(true);

            nine.setContentAreaFilled(true);
            nine.setBorderPainted(false);
            nine.setIconTextGap(-2);

            nine.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                nine.setBackground(new java.awt.Color(0, 0, 0));
                nine.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                nine.setBackground(new java.awt.Color(248, 249, 250));
                nine.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                nine.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                nine.setBackground(new java.awt.Color(248, 249, 250));
                nine.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button ENTER (JButtons) Declarations.
            ButtonsPanel.add(Enter);
            Enter.setBackground(new java.awt.Color(248, 249, 250));
            Enter.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            Enter.setFocusPainted(false);
            Enter.setHorizontalAlignment(SwingConstants.CENTER);
            Enter.setOpaque(false);
            Enter.setForeground(new java.awt.Color(0,0,0));
            Enter.setText("ENTER");
            Enter.setVisible(true);

            Enter.setContentAreaFilled(true);
            Enter.setBorderPainted(false);
            Enter.setIconTextGap(-2);

            Enter.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                Enter.setBackground(new java.awt.Color(0, 0, 0));
                Enter.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                Enter.setBackground(new java.awt.Color(248, 249, 250));
                Enter.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                Enter.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                Enter.setBackground(new java.awt.Color(248, 249, 250));
                Enter.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button 0 (JButtons) Declarations.
            ButtonsPanel.add(zero);
            zero.setBackground(new java.awt.Color(248, 249, 250));
            zero.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            zero.setFocusPainted(false);
            zero.setHorizontalAlignment(SwingConstants.CENTER);
            zero.setOpaque(false);
            zero.setForeground(new java.awt.Color(0,0,0));
            zero.setText("0");
            zero.setVisible(true);

            zero.setContentAreaFilled(true);
            zero.setBorderPainted(false);
            zero.setIconTextGap(-2);

            zero.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                zero.setBackground(new java.awt.Color(0, 0, 0));
                zero.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                zero.setBackground(new java.awt.Color(248, 249, 250));
                zero.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                zero.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                zero.setBackground(new java.awt.Color(248, 249, 250));
                zero.setForeground(new java.awt.Color(0,0,0));
            }

            });
            
            // Button Reset (JButtons) Declarations.
            ButtonsPanel.add(Reset);
            Reset.setBackground(new java.awt.Color(248, 249, 250));
            Reset.setFont(new java.awt.Font("Impact", Font.PLAIN, 16));
            Reset.setFocusPainted(false);
            Reset.setHorizontalAlignment(SwingConstants.CENTER);
            Reset.setOpaque(false);
            Reset.setForeground(new java.awt.Color(0,0,0));
            Reset.setText("RESET");
            Reset.setVisible(true);

            Reset.setContentAreaFilled(true);
            Reset.setBorderPainted(false);
            Reset.setIconTextGap(-2);

            Reset.addMouseListener(new MouseAdapter(){

            @Override
            public void mousePressed(MouseEvent e) {
                Reset.setBackground(new java.awt.Color(0, 0, 0));
                Reset.setForeground(new java.awt.Color(255,255,255));
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                Reset.setBackground(new java.awt.Color(248, 249, 250));
                Reset.setForeground(new java.awt.Color(0,0,0));
            }

            @Override
            public void mouseEntered(MouseEvent e){
                Reset.setBackground(new java.awt.Color(150,150,150));
            }

            @Override
            public void mouseExited(MouseEvent e){
                Reset.setBackground(new java.awt.Color(248, 249, 250));
                Reset.setForeground(new java.awt.Color(0,0,0));
            }

            });
       
        
        
    }
    

    public static void main(String[] args) {
        
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JavaSwingOven.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }/*/ /*/
        
        JavaSwingOven open = new JavaSwingOven();
        open.setVisible(true);
        
        
    }
    
}
