package resumeswing;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.netbeans.lib.awtextra.AbsoluteConstraints;

public class ResumeSwing {

    static void BrionResume() {

        final int MaxFrameSizeX = 1366;
        final int MaxFrameSizeY = 746;

        final int MinFrameSizeX = 1366;
        final int MinFrameSizeY = 746;

        JFrame mainFrame = new JFrame();

        // JFrame Size
        mainFrame.setSize(MinFrameSizeX, MinFrameSizeY);
        mainFrame.setMinimumSize(new java.awt.Dimension(MinFrameSizeX, MinFrameSizeY));
        mainFrame.setPreferredSize(new java.awt.Dimension(MaxFrameSizeX, MaxFrameSizeY));
        mainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //JFrame Decoration
        mainFrame.setUndecorated(false);
        mainFrame.setOpacity(1.0f);
        mainFrame.setTitle("COMPROG 3 : Activity 2 | Brion Resume.");
        mainFrame.setLayout(null);

        // CENTER POPUP MAIN WINDOW
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation(dimension.width / 2 - mainFrame.getWidth() / 2, dimension.height / 2 - mainFrame.getHeight() / 2);

        // JPanel titleBar 
        final int titleBarHeigth = 128;
        final int titleBarWidth = 1366;
        final int titleBarLocationX = 0;
        final int titleBarLocationY = 0;

        JPanel titleBar = new JPanel();

        // titleBar (JPanel) Decorations.
        titleBar.setBounds(titleBarLocationX, titleBarLocationY, titleBarWidth, titleBarHeigth);
        mainFrame.add(titleBar, new AbsoluteConstraints(titleBarLocationX, titleBarLocationY, titleBarWidth, titleBarHeigth));
        titleBar.setBackground(new java.awt.Color(0, 0, 35));
        titleBar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 208, 0), 2, false));
        titleBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Logo (JLabel) Declarations.
        final int logoHeight = 158;
        final int logoWidth = 158;
        final int logoLocationX = 350;
        final int logoLocationY = 5;

        JLabel logo = new JLabel();

        // Logo (JLabel) Decorations.
        logo.setBounds(logoLocationX, logoLocationY, logoWidth, logoHeight);
        titleBar.add(logo, new AbsoluteConstraints(logoLocationX, logoLocationY, logoWidth, logoHeight));
        logo.setForeground(new java.awt.Color(0, 0, 0));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon logoGetter = new ImageIcon("src\\res\\Brion-Tactical-Systems.png");
        Image getLogo = logoGetter.getImage();
        Image scaleLogo = getLogo.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayLogo = new ImageIcon(scaleLogo);
        logo.setIcon(displayLogo);

        // Logo Text (JLabel) Declarations.
        Font IronShark;

        final int companyNameHeight = 20;
        final int companyNameWidth = 600;
        final int companyNameLocationX = 470;
        final int companyNameLocationY = 50;

        JLabel companyName = new JLabel();

        final int cNameShadowLocationY = 54;

        JLabel cNameShadow = new JLabel();

        companyName.setBounds(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight);
        titleBar.add(companyName, new AbsoluteConstraints(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight));
        companyName.setForeground(new java.awt.Color(255, 208, 0));
        companyName.setFont(new java.awt.Font("Iron Shark", 0, 20));

        cNameShadow.setBounds(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight);
        titleBar.add(cNameShadow, new AbsoluteConstraints(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight));
        cNameShadow.setForeground(new java.awt.Color(0, 0, 0));
        cNameShadow.setFont(new java.awt.Font("Iron Shark", 0, 20));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        companyName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        companyName.setText("Brion Tactical Systems");
        companyName.setVisible(true);

        cNameShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cNameShadow.setText("Brion Tactical Systems");
        cNameShadow.setVisible(true);

        // Activity Title 
        final int mainTextHeight = 50;
        final int mainTextWidth = 600;
        final int mainTextX = 500;
        final int mainTextY = 60;

        JLabel mainText = new JLabel();

        mainText.setBounds(mainTextX, mainTextY, mainTextWidth, mainTextHeight);
        titleBar.add(mainText, new AbsoluteConstraints(mainTextX, mainTextY, mainTextWidth, mainTextHeight));
        mainText.setForeground(new java.awt.Color(255, 255, 255));
        mainText.setFont(new java.awt.Font("Tahoma", 1, 20));

        mainText.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        mainText.setText("JAVA SWING ACTIVITY #2 | GROUP 8 (BRION RESUME)");
        mainText.setVisible(true);

        // Document (JPanel) Declarations.
        final int DocHeight = 579;
        final int DocWidth = 1366;
        final int DocLocationX = 0;
        final int DocLocationY = 128;

        JPanel Doc = new JPanel();

        // Document (JPanel) Decorations.
        Doc.setBounds(DocLocationX, DocLocationY, DocWidth, DocHeight);
        mainFrame.add(Doc, new AbsoluteConstraints(DocLocationX, DocLocationY, DocWidth, DocHeight));
        Doc.setBackground(new java.awt.Color(242, 204, 143));
        Doc.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 200, 0), 0, false));
        Doc.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Doc.setVisible(true);

        // Applicant's Name (JLabel) Declarations.
        final int nameLocationX = 570;
        final int nameLocationY = 20;
        final int nameWidth = 600;
        final int nameHeight = 45;

        JLabel name = new JLabel();

        // Applicant's Name (JLabel) Decorations.
        name.setBounds(nameLocationX, nameLocationY, nameWidth, nameHeight);
        Doc.add(name, new AbsoluteConstraints(nameLocationX, nameLocationY, nameWidth, nameHeight));
        name.setForeground(new java.awt.Color(0, 0, 0));
        name.setFont(new java.awt.Font("Times New Roman", 1, 60));

        name.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        name.setText("JHON BRIX BRION");
        name.setVisible(true);

        // Applicant's Job Role (JLabel) Declarations.
        final int jobRoleLocationX = 630;
        final int jobRoleLocationY = 80;
        final int jobRoleWidth = 600;
        final int jobRoleHeight = 20;

        JLabel jobRole = new JLabel();

        // Applicant's Job Role (JLabel) Decorations.
        jobRole.setBounds(jobRoleLocationX, jobRoleLocationY, jobRoleWidth, jobRoleHeight);
        Doc.add(jobRole, new AbsoluteConstraints(jobRoleLocationX, jobRoleLocationY, jobRoleWidth, jobRoleHeight));
        jobRole.setForeground(new java.awt.Color(0, 0, 0));
        jobRole.setFont(new java.awt.Font("Calibri", 0, 20));

        jobRole.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        jobRole.setText("JAVA SOFTWARE ENGINEER / SOFTWARE DEVELOPER");
        jobRole.setVisible(true);

        // Educational Background (JLabel) Declarations.
        final int EBackgroundLocationX = 320;
        final int EBackgroundLocationY = 140;
        final int EBackgroundWidth = 300;
        final int EBackgroundHeigth = 27;

        JLabel EBackground = new JLabel();

        // Educational Background (JLabel) Decorations.
        EBackground.setBounds(EBackgroundLocationX, EBackgroundLocationY, EBackgroundWidth, EBackgroundHeigth);
        Doc.add(EBackground, new AbsoluteConstraints(EBackgroundLocationX, EBackgroundLocationY, EBackgroundWidth, EBackgroundHeigth));
        EBackground.setForeground(new java.awt.Color(0, 0, 0));
        EBackground.setFont(new java.awt.Font("Times New Roman", 1, 18));

        EBackground.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EBackground.setText("EDUCATIONAL BACKGROUND");
        EBackground.setVisible(true);

        // Educational Background Informations.
        // Elementary Info (JLabel) Declarations.
        final int ElementaryLocationX = 320;
        final int ElementaryLocationY = 170;
        final int ElementaryWidth = 300;
        final int ElementaryHeight = 27;

        JLabel Elementary = new JLabel();

        // Elementary (JLabel) Decorations.
        Elementary.setBounds(ElementaryLocationX, ElementaryLocationY, ElementaryWidth, ElementaryHeight);
        Doc.add(Elementary, new AbsoluteConstraints(ElementaryLocationX, ElementaryLocationY, ElementaryWidth, ElementaryHeight));
        Elementary.setForeground(new java.awt.Color(0, 0, 0));
        Elementary.setFont(new java.awt.Font("Calibri", 0, 16));

        Elementary.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Elementary.setText("Gerona Ecumenical Christian School");
        Elementary.setVisible(true);

        // Elementary Year (JLabel) Declarations.
        final int ElemSYLocationX = 320;
        final int ElemSYLocationY = 190;
        final int ElemSYWidth = 300;
        final int ElemSYHeight = 27;

        JLabel ElemSY = new JLabel();

        // Elementary Year (JLabel) Decorations.
        ElemSY.setBounds(ElemSYLocationX, ElemSYLocationY, ElemSYWidth, ElemSYHeight);
        Doc.add(ElemSY, new AbsoluteConstraints(ElemSYLocationX, ElemSYLocationY, ElemSYWidth, ElemSYHeight));
        ElemSY.setForeground(new java.awt.Color(0, 0, 0));
        ElemSY.setFont(new java.awt.Font("Calibri", 0, 18));

        ElemSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ElemSY.setText("S.Y 2008 - 2014 (Elementary)");
        ElemSY.setVisible(true);

        // Junior High School Info (JLabel) Declarations.
        final int JHSLocationX = 320;
        final int JHSLocationY = 230;
        final int JHSWidth = 300;
        final int JHSHeight = 27;

        JLabel JHS = new JLabel();

        // Junior High School Info (JLabel) Decorations.
        JHS.setBounds(JHSLocationX, JHSLocationY, JHSWidth, JHSHeight);
        Doc.add(JHS, new AbsoluteConstraints(JHSLocationX, JHSLocationY, JHSWidth, JHSHeight));
        JHS.setForeground(new java.awt.Color(0, 0, 0));
        JHS.setFont(new java.awt.Font("Calibri", 0, 16));

        JHS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JHS.setText("Gerona Ecumenical Christian School");
        JHS.setVisible(true);

        // Senior High School Year (JLabel) Declarations.
        final int JHSSchoolYearLocationX = 320;
        final int JHSSchoolYearLocationY = 250;
        final int JHSSchoolYearWidth = 300;
        final int JHSSchoolYearHeight = 27;

        JLabel JuniorHighSchoolSY = new JLabel();

        // Senior High School Year (JLabel) Decorations.
        JuniorHighSchoolSY.setBounds(JHSSchoolYearLocationX, JHSSchoolYearLocationY, JHSSchoolYearWidth, JHSSchoolYearHeight);
        Doc.add(JuniorHighSchoolSY, new AbsoluteConstraints(JHSSchoolYearLocationX, JHSSchoolYearLocationY, JHSSchoolYearWidth, JHSSchoolYearHeight));
        JuniorHighSchoolSY.setForeground(new java.awt.Color(0, 0, 0));
        JuniorHighSchoolSY.setFont(new java.awt.Font("Calibri", 0, 18));

        JuniorHighSchoolSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JuniorHighSchoolSY.setText("S.Y 2014 - 2018 (Junior High School)");
        JuniorHighSchoolSY.setVisible(true);

        // Senior High School Info (JLabel) Declarations.
        final int SHSLocationX = 320;
        final int SHSLocationY = 290;
        final int SHSWidth = 300;
        final int SHSHeight = 27;

        JLabel SHS = new JLabel();

        // Senior High School Info (JLabel) Decorations.
        SHS.setBounds(SHSLocationX, SHSLocationY, SHSWidth, SHSHeight);
        Doc.add(SHS, new AbsoluteConstraints(SHSLocationX, SHSLocationY, SHSWidth, SHSHeight));
        SHS.setForeground(new java.awt.Color(0, 0, 0));
        SHS.setFont(new java.awt.Font("Calibri", 0, 16));

        SHS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SHS.setText("Gerona Junior College");
        SHS.setVisible(true);

        // Senior High School Year (JLabel) Declarations.
        final int SeniorHighSchoolSYLocationX = 320;
        final int SeniorHighSchoolSYLocationY = 310;
        final int SeniorHighSchoolSYWidth = 300;
        final int SeniorHighSchoolSYHeight = 27;

        JLabel SeniorHighSchoolSY = new JLabel();

        // High School Year (JLabel) Decorations.
        SeniorHighSchoolSY.setBounds(SeniorHighSchoolSYLocationX, SeniorHighSchoolSYLocationY, SeniorHighSchoolSYWidth, SeniorHighSchoolSYHeight);
        Doc.add(SeniorHighSchoolSY, new AbsoluteConstraints(SeniorHighSchoolSYLocationX, SeniorHighSchoolSYLocationY, SeniorHighSchoolSYWidth, SeniorHighSchoolSYHeight));
        SeniorHighSchoolSY.setForeground(new java.awt.Color(0, 0, 0));
        SeniorHighSchoolSY.setFont(new java.awt.Font("Calibri", 0, 18));

        SeniorHighSchoolSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SeniorHighSchoolSY.setText("S.Y 2018 - 2020 (Senior High School)");
        SeniorHighSchoolSY.setVisible(true);

        // College Scool Info (JLabel) Declarations.
        final int CollegeLocationX = 320;
        final int CollegeLocationY = 350;
        final int CollegeWidth = 300;
        final int CollegeHeight = 27;

        JLabel College = new JLabel();

        // College School Info (JLabel) Decorations.
        College.setBounds(CollegeLocationX, CollegeLocationY, CollegeWidth, CollegeHeight);
        Doc.add(College, new AbsoluteConstraints(CollegeLocationX, CollegeLocationY, CollegeWidth, CollegeHeight));
        College.setForeground(new java.awt.Color(0, 0, 0));
        College.setFont(new java.awt.Font("Calibri", 0, 16));

        College.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        College.setText("Tarlac State University");
        College.setVisible(true);

        // College School Year (JLabel) Declarations.
        final int CollegeSYLocationX = 320;
        final int CollegeSYLocationY = 370;
        final int CollegeSYWidth = 300;
        final int CollegeSYHeight = 27;

        JLabel CollegeSY = new JLabel();

        // College School Year (JLabel) Decorations.
        CollegeSY.setBounds(CollegeSYLocationX, CollegeSYLocationY, CollegeSYWidth, CollegeSYHeight);
        Doc.add(CollegeSY, new AbsoluteConstraints(CollegeSYLocationX, CollegeSYLocationY, CollegeSYWidth, CollegeSYHeight));
        CollegeSY.setForeground(new java.awt.Color(0, 0, 0));
        CollegeSY.setFont(new java.awt.Font("Calibri", 0, 18));

        CollegeSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CollegeSY.setText("S.Y 2020 - Present (College)");
        CollegeSY.setVisible(true);

        // Skills Background (JLabel) Declarations.
        final int SkillsLocationX = 640;
        final int SkillsLocationY = 140;
        final int SkillsWidth = 300;
        final int SkillsHeigth = 27;

        JLabel Skills = new JLabel();

        // Skills Background (JLabel) Decorations.
        Skills.setBounds(SkillsLocationX, SkillsLocationY, SkillsWidth, SkillsHeigth);
        Doc.add(Skills, new AbsoluteConstraints(SkillsLocationX, SkillsLocationY, SkillsWidth, SkillsHeigth));
        Skills.setForeground(new java.awt.Color(0, 0, 0));
        Skills.setFont(new java.awt.Font("Times New Roman", 1, 18));

        Skills.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills.setText("SKILLS");
        Skills.setVisible(true);

        // Skills Info (JLabel) Declarations
        final int Skills1LocationX = 640;
        final int Skills1LocationY = 170;
        final int Skills1Width = 300;
        final int Skills1Height = 27;

        JLabel Skills1 = new JLabel();

        // Skills Info (JLabel) Decorations.
        Skills1.setBounds(Skills1LocationX, Skills1LocationY, Skills1Width, Skills1Height);
        Doc.add(Skills1, new AbsoluteConstraints(Skills1LocationX, Skills1LocationY, Skills1Width, Skills1Height));
        Skills1.setForeground(new java.awt.Color(0, 0, 0));
        Skills1.setFont(new java.awt.Font("Calibri", 0, 18));

        Skills1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills1.setText("Photography/Videography");
        Skills1.setVisible(true);

        // Skills Info 2 (JLabel) Declarations
        final int Skills2LocationX = 640;
        final int Skills2LocationY = 200;
        final int Skills2Width = 300;
        final int Skills2Height = 27;

        JLabel Skills2 = new JLabel();

        // Skills Info 2(JLabel) Decorations.
        Skills2.setBounds(Skills2LocationX, Skills2LocationY, Skills2Width, Skills2Height);
        Doc.add(Skills2, new AbsoluteConstraints(Skills2LocationX, Skills2LocationY, Skills2Width, Skills2Height));
        Skills2.setForeground(new java.awt.Color(0, 0, 0));
        Skills2.setFont(new java.awt.Font("Calibri", 0, 18));

        Skills2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills2.setText("Good Communication Skills");
        Skills2.setVisible(true);

        // Skills Info 3 (JLabel) Declarations
        final int Skills3LocationX = 640;
        final int Skills3LocationY = 230;
        final int Skills3Width = 300;
        final int Skills3Height = 27;

        JLabel Skills3 = new JLabel();

        // Skills Info 3(JLabel) Decorations.
        Skills3.setBounds(Skills3LocationX, Skills3LocationY, Skills3Width, Skills3Height);
        Doc.add(Skills3, new AbsoluteConstraints(Skills3LocationX, Skills3LocationY, Skills3Width, Skills3Height));
        Skills3.setForeground(new java.awt.Color(0, 0, 0));
        Skills3.setFont(new java.awt.Font("Calibri", 0, 18));

        Skills3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills3.setText("UI/UX Design");
        Skills3.setVisible(true);

        // Skills Info 4 (JLabel) Declarations
        final int Skills4LocationX = 640;
        final int Skills4LocationY = 260;
        final int Skills4Width = 300;
        final int Skills4Height = 27;

        JLabel Skills4 = new JLabel();

        // Skills Info 4(JLabel) Decorations.
        Skills4.setBounds(Skills4LocationX, Skills4LocationY, Skills4Width, Skills4Height);
        Doc.add(Skills4, new AbsoluteConstraints(Skills4LocationX, Skills4LocationY, Skills4Width, Skills4Height));
        Skills4.setForeground(new java.awt.Color(0, 0, 0));
        Skills4.setFont(new java.awt.Font("Calibri", 0, 18));

        Skills4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills4.setText("Robust Code Management");
        Skills4.setVisible(true);

        // Skills Info 5 (JLabel) Declarations
        final int Skills5LocationX = 640;
        final int Skills5LocationY = 290;
        final int Skills5Width = 300;
        final int Skills5Height = 27;

        JLabel Skills5 = new JLabel();

        // Skills Info 5(JLabel) Decorations.
        Skills5.setBounds(Skills5LocationX, Skills5LocationY, Skills5Width, Skills5Height);
        Doc.add(Skills5, new AbsoluteConstraints(Skills5LocationX, Skills5LocationY, Skills5Width, Skills5Height));
        Skills5.setForeground(new java.awt.Color(0, 0, 0));
        Skills5.setFont(new java.awt.Font("Calibri", 0, 18));

        Skills5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills5.setText("Coding and Software Development");
        Skills5.setVisible(true);

        // Favorites Background (JLabel) Declarations.
        final int FavoritesLocationX = 950;
        final int FavoritesLocationY = 140;
        final int FavoritesWidth = 300;
        final int FavoritesHeigth = 27;

        JLabel Favorites = new JLabel();

        // Favorites Background (JLabel) Decorations.
        Favorites.setBounds(FavoritesLocationX, FavoritesLocationY, FavoritesWidth, FavoritesHeigth);
        Doc.add(Favorites, new AbsoluteConstraints(FavoritesLocationX, FavoritesLocationY, FavoritesWidth, FavoritesHeigth));
        Favorites.setForeground(new java.awt.Color(0, 0, 0));
        Favorites.setFont(new java.awt.Font("Times New Roman", 1, 18));

        Favorites.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Favorites.setText("FAVORITES");
        Favorites.setVisible(true);

        // Favorites Info 1 (JLabel) Declarations
        final int Favorites1LocationX = 950;
        final int Favorites1LocationY = 170;
        final int Favorites1Width = 300;
        final int Favorites1Height = 27;

        JLabel Favorites1 = new JLabel();

        // Favorites Info 1 (JLabel) Decorations.
        Favorites1.setBounds(Favorites1LocationX, Favorites1LocationY, Favorites1Width, Favorites1Height);
        Doc.add(Favorites1, new AbsoluteConstraints(Favorites1LocationX, Favorites1LocationY, Favorites1Width, Favorites1Height));
        Favorites1.setForeground(new java.awt.Color(0, 0, 0));
        Favorites1.setFont(new java.awt.Font("Calibri", 0, 18));

        Favorites1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Favorites1.setText("Maze Runner Series (MOVIE)");
        Favorites1.setVisible(true);

        // Favorites Info 2 (JLabel) Declarations
        final int Favorites2LocationX = 950;
        final int Favorites2LocationY = 200;
        final int Favorites2Width = 300;
        final int Favorites2Height = 27;

        JLabel Favorites2 = new JLabel();

        // Favorites Info 2 (JLabel) Decorations.
        Favorites2.setBounds(Favorites2LocationX, Favorites2LocationY, Favorites2Width, Favorites2Height);
        Doc.add(Favorites2, new AbsoluteConstraints(Favorites2LocationX, Favorites2LocationY, Favorites2Width, Favorites2Height));
        Favorites2.setForeground(new java.awt.Color(0, 0, 0));
        Favorites2.setFont(new java.awt.Font("Calibri", 0, 18));

        Favorites2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Favorites2.setText("Atomic Habbits (BOOK)");
        Favorites2.setVisible(true);

        // Favorites Info 3 (JLabel) Declarations
        final int Favorites3LocationX = 950;
        final int Favorites3LocationY = 230;
        final int Favorites3Width = 300;
        final int Favorites3Height = 27;

        JLabel Favorites3 = new JLabel();

        // Favorites Info 3 (JLabel) Decorations.
        Favorites3.setBounds(Favorites3LocationX, Favorites3LocationY, Favorites3Width, Favorites3Height);
        Doc.add(Favorites3, new AbsoluteConstraints(Favorites3LocationX, Favorites3LocationY, Favorites3Width, Favorites3Height));
        Favorites3.setForeground(new java.awt.Color(0, 0, 0));
        Favorites3.setFont(new java.awt.Font("Calibri", 0, 18));

        Favorites3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Favorites3.setText("BTS Songs (MUSIC)");
        Favorites3.setVisible(true);

        // Left Pane (JPanel) Declarations.
        final int LeftPaneHeight = 579;
        final int LeftPaneWidth = 300;
        final int LeftPaneLocationX = 0;
        final int LeftPaneLocationY = 0;

        JPanel LeftPane = new JPanel();

        // Left Pane (JPanel) Decorations.
        LeftPane.setBounds(LeftPaneLocationX, LeftPaneLocationY, LeftPaneWidth, LeftPaneHeight);
        Doc.add(LeftPane, new AbsoluteConstraints(LeftPaneLocationX, LeftPaneLocationY, LeftPaneWidth, LeftPaneHeight));
        LeftPane.setBackground(new java.awt.Color(0, 0, 0));
        LeftPane.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(224, 122, 95), 2, false));
        LeftPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        LeftPane.setVisible(true);

        // Picture Frame (JPanel) Declarations.
        final int pictureFrameHeigth = 200;
        final int pictureFrameWidth = 200;
        final int pictureFrameLocationX = 50;
        final int pictureFrameLocationY = 10;

        JPanel pictureFrame = new JPanel();

        // Picture Frame (JPanel) Decorations.
        pictureFrame.setBounds(pictureFrameLocationX, pictureFrameLocationY, pictureFrameWidth, pictureFrameHeigth);
        LeftPane.add(pictureFrame, new AbsoluteConstraints(pictureFrameLocationX, pictureFrameLocationY, pictureFrameWidth, pictureFrameHeigth));
        pictureFrame.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(224, 122, 95), 2, false));
        pictureFrame.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Picture (JLabel) Declarations.
        final int pictureHeight = 196;
        final int pictureWidth = 196;
        final int pictureLocationX = 2;
        final int pictureLocationY = 2;

        JLabel picture = new JLabel();

        // Picture (JLabel) Decorations;
        picture.setBounds(pictureLocationX, pictureLocationY, pictureWidth, pictureHeight);
        pictureFrame.add(picture, new AbsoluteConstraints(pictureLocationX, pictureLocationY, pictureWidth, pictureHeight));
        picture.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picture.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon pictureGetter = new ImageIcon("src\\res\\BrionPicture.jpg");
        Image getPicture = pictureGetter.getImage();
        Image scaledPicture = getPicture.getScaledInstance(picture.getWidth(), picture.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayPicture = new ImageIcon(scaledPicture);
        picture.setIcon(displayPicture);

        // Personal Information Banner (JPanel) Declarations.
        final int personalInfoLocationX = 50;
        final int perosnalInfoLocationY = 230;
        final int personalInfoWidth = 252;
        final int personalInfoHeight = 30;

        JPanel personalInfo = new JPanel();

        // Personal Information Banner (JPanel) Decorations.
        personalInfo.setBounds(personalInfoLocationX, perosnalInfoLocationY, personalInfoWidth, personalInfoHeight);
        LeftPane.add(personalInfo, new AbsoluteConstraints(personalInfoLocationX, perosnalInfoLocationY, personalInfoWidth, personalInfoHeight));
        personalInfo.setBackground(new java.awt.Color(242, 204, 143));
        personalInfo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(224, 122, 95), 2, false));
        personalInfo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        personalInfo.setVisible(true);

        // Personal Information Banner Text (JPanel) Declarations.
        final int personalInfoTextLocationX = 12;
        final int personalInfoTextLocationY = 2;
        final int personalInfoTextWidth = 248;
        final int personalInfoTextHeight = 27;

        JLabel personalInfoText = new JLabel();

        // Personal Information Banner Text (JPanel) Decorations.
        personalInfoText.setBounds(personalInfoTextLocationX, personalInfoTextLocationY, personalInfoTextWidth, personalInfoTextHeight);
        personalInfo.add(personalInfoText, new AbsoluteConstraints(personalInfoTextLocationX, personalInfoTextLocationY, personalInfoTextWidth, personalInfoTextHeight));
        personalInfoText.setForeground(new java.awt.Color(0, 0, 0));
        personalInfoText.setFont(new java.awt.Font("Times New Roman", 1, 18));

        personalInfoText.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        personalInfoText.setText("PERSONAL INFORMATION");
        personalInfoText.setVisible(true);

        // Address (JLabel) Declarations.
        final int AddressBannerLocationX = 30;
        final int AddressBannerLocationY = 260;
        final int AddressBannerWidth = 200;
        final int AddressBannerHeight = 27;

        JLabel addressBanner = new JLabel();

        // Address (JLabel) Decorations.
        addressBanner.setBounds(AddressBannerLocationX, AddressBannerLocationY, AddressBannerWidth, AddressBannerHeight);
        LeftPane.add(addressBanner, new AbsoluteConstraints(AddressBannerLocationX, AddressBannerLocationY, AddressBannerWidth, AddressBannerHeight));
        addressBanner.setForeground(new java.awt.Color(255, 255, 255));
        addressBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        addressBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        addressBanner.setText("ADDRESS");
        addressBanner.setVisible(true);

        // Address Info (JLabel) Declarations.
        final int AddressInfoLocationX = 30;
        final int AddressInfoLocationY = 280;
        final int AddressInfoWidth = 300;
        final int AddressInfoHeight = 27;

        JLabel AddressInfo = new JLabel();

        // Address Indo (JLabel) Decorations.
        AddressInfo.setBounds(AddressInfoLocationX, AddressInfoLocationY, AddressInfoWidth, AddressInfoHeight);
        LeftPane.add(AddressInfo, new AbsoluteConstraints(AddressInfoLocationX, AddressInfoLocationY, AddressInfoWidth, AddressInfoHeight));
        AddressInfo.setForeground(new java.awt.Color(255, 255, 255));
        AddressInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        AddressInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        AddressInfo.setText("283 St. San Antonio, Gerona, Tarlac");
        AddressInfo.setVisible(true);

        // Address Info2 (JLabel) Declarations.
        final int AddressInfo2LocationX = 30;
        final int AddressInfo2LocationY = 300;
        final int AddressInfo2Width = 300;
        final int AddressInfo2Height = 27;

        JLabel AddressInfo2 = new JLabel();

        // Address Indo2 (JLabel) Decorations.
        AddressInfo2.setBounds(AddressInfo2LocationX, AddressInfo2LocationY, AddressInfo2Width, AddressInfo2Height);
        LeftPane.add(AddressInfo2, new AbsoluteConstraints(AddressInfo2LocationX, AddressInfo2LocationY, AddressInfo2Width, AddressInfo2Height));
        AddressInfo2.setForeground(new java.awt.Color(255, 255, 255));
        AddressInfo2.setFont(new java.awt.Font("Calibri", 0, 14));

        AddressInfo2.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        AddressInfo2.setText("Philippines");
        AddressInfo2.setVisible(true);

        // Birthdate (JLabel) Declarations.
        final int BirthdateBannerLocationX = 30;
        final int BirthdateBannerLocationY = 320;
        final int BirthdateBannerWidth = 200;
        final int BirthdateBannerHeight = 27;

        JLabel BirthdateBanner = new JLabel();

        // Birthdate (JLabel) Decorations.
        BirthdateBanner.setBounds(BirthdateBannerLocationX, BirthdateBannerLocationY, BirthdateBannerWidth, BirthdateBannerHeight);
        LeftPane.add(BirthdateBanner, new AbsoluteConstraints(BirthdateBannerLocationX, BirthdateBannerLocationY, BirthdateBannerWidth, BirthdateBannerHeight));
        BirthdateBanner.setForeground(new java.awt.Color(255, 255, 255));
        BirthdateBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        BirthdateBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        BirthdateBanner.setText("BIRTHDATE");
        BirthdateBanner.setVisible(true);

        // Birthdate Info (JLabel) Declarations.
        final int BirthdateInfoLocationX = 30;
        final int BirthdateInfoLocationY = 340;
        final int BirthdateInfoWidth = 300;
        final int BirthdateInfoHeight = 27;

        JLabel BirthdateInfo = new JLabel();

        // Birthdate Indo (JLabel) Decorations.
        BirthdateInfo.setBounds(BirthdateInfoLocationX, BirthdateInfoLocationY, BirthdateInfoWidth, BirthdateInfoHeight);
        LeftPane.add(BirthdateInfo, new AbsoluteConstraints(BirthdateInfoLocationX, BirthdateInfoLocationY, BirthdateInfoWidth, BirthdateInfoHeight));
        BirthdateInfo.setForeground(new java.awt.Color(255, 255, 255));
        BirthdateInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        BirthdateInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        BirthdateInfo.setText("July 1, 2002");
        BirthdateInfo.setVisible(true);

        // Citizenship (JLabel) Declarations.
        final int CitizenshipBannerLocationX = 30;
        final int CitizenshipBannerLocationY = 360;
        final int CitizenshipBannerWidth = 200;
        final int CitizenshipBannerHeight = 27;

        JLabel CitizenshipBanner = new JLabel();

        // Citizenship Banner (JLabel) Decorations.
        CitizenshipBanner.setBounds(CitizenshipBannerLocationX, CitizenshipBannerLocationY, CitizenshipBannerWidth, CitizenshipBannerHeight);
        LeftPane.add(CitizenshipBanner, new AbsoluteConstraints(CitizenshipBannerLocationX, CitizenshipBannerLocationY, CitizenshipBannerWidth, CitizenshipBannerHeight));
        CitizenshipBanner.setForeground(new java.awt.Color(255, 255, 255));
        CitizenshipBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        CitizenshipBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        CitizenshipBanner.setText("CITIZENSHIP");
        CitizenshipBanner.setVisible(true);

        // Citizenship Info (JLabel) Declarations.
        final int CitizenshipInfoLocationX = 30;
        final int CitizenshipInfoLocationY = 380;
        final int CitizenshipInfoWidth = 300;
        final int CitizenshipInfoHeight = 27;

        JLabel CitizenshipInfo = new JLabel();

        // Citizenship Info (JLabel) Decorations.
        CitizenshipInfo.setBounds(CitizenshipInfoLocationX, CitizenshipInfoLocationY, CitizenshipInfoWidth, CitizenshipInfoHeight);
        LeftPane.add(CitizenshipInfo, new AbsoluteConstraints(CitizenshipInfoLocationX, CitizenshipInfoLocationY, CitizenshipInfoWidth, CitizenshipInfoHeight));
        CitizenshipInfo.setForeground(new java.awt.Color(255, 255, 255));
        CitizenshipInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        CitizenshipInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        CitizenshipInfo.setText("Filipino");
        CitizenshipInfo.setVisible(true);

        // Religion (JLabel) Declarations.
        final int ReligionBannerLocationX = 30;
        final int ReligionBannerLocationY = 400;
        final int ReligionBannerWidth = 200;
        final int ReligionBannerHeight = 27;

        JLabel ReligionBanner = new JLabel();

        // Religion Banner (JLabel) Decorations.
        ReligionBanner.setBounds(ReligionBannerLocationX, ReligionBannerLocationY, ReligionBannerWidth, ReligionBannerHeight);
        LeftPane.add(ReligionBanner, new AbsoluteConstraints(ReligionBannerLocationX, ReligionBannerLocationY, ReligionBannerWidth, ReligionBannerHeight));
        ReligionBanner.setForeground(new java.awt.Color(255, 255, 255));
        ReligionBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        ReligionBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ReligionBanner.setText("RELIGION");
        ReligionBanner.setVisible(true);

        // Religion Info (JLabel) Declarations.
        final int ReligionInfoLocationX = 30;
        final int ReligionInfoLocationY = 420;
        final int ReligionInfoWidth = 300;
        final int ReligionInfoHeight = 27;

        JLabel ReligionInfo = new JLabel();

        // Religion Info (JLabel) Decorations.
        ReligionInfo.setBounds(ReligionInfoLocationX, ReligionInfoLocationY, ReligionInfoWidth, ReligionInfoHeight);
        LeftPane.add(ReligionInfo, new AbsoluteConstraints(ReligionInfoLocationX, ReligionInfoLocationY, ReligionInfoWidth, ReligionInfoHeight));
        ReligionInfo.setForeground(new java.awt.Color(255, 255, 255));
        ReligionInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        ReligionInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ReligionInfo.setText("Catholic");
        ReligionInfo.setVisible(true);

        // Contacts (JLabel) Declarations.
        final int ContactBannerLocationX = 30;
        final int ContactBannerLocationY = 440;
        final int ContactBannerWidth = 200;
        final int ContactBannerHeight = 27;

        JLabel ContactsBanner = new JLabel();

        // Contacts Banner (JLabel) Decorations.
        ContactsBanner.setBounds(ContactBannerLocationX, ContactBannerLocationY, ContactBannerWidth, ContactBannerHeight);
        LeftPane.add(ContactsBanner, new AbsoluteConstraints(ContactBannerLocationX, ContactBannerLocationY, ReligionBannerWidth, ContactBannerHeight));
        ContactsBanner.setForeground(new java.awt.Color(255, 255, 255));
        ContactsBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        ContactsBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ContactsBanner.setText("CONTACTS");
        ContactsBanner.setVisible(true);

        // Contacts Info (JLabel) Declarations.
        final int ContactsInfoLocationX = 30;
        final int ContactsInfoLocationY = 460;
        final int ContactsInfoWidth = 300;
        final int ContactsInfoHeight = 27;

        JLabel ContactsInfo = new JLabel();

        // Contacts Info (JLabel) Decorations.
        ContactsInfo.setBounds(ContactsInfoLocationX, ContactsInfoLocationY, ContactsInfoWidth, ContactsInfoHeight);
        LeftPane.add(ContactsInfo, new AbsoluteConstraints(ContactsInfoLocationX, ContactsInfoLocationY, ContactsInfoWidth, ContactsInfoHeight));
        ContactsInfo.setForeground(new java.awt.Color(255, 255, 255));
        ContactsInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        ContactsInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ContactsInfo.setText("0915-9636-750");
        ContactsInfo.setVisible(true);

        // Email (JLabel) Declarations.
        final int EmailLocationX = 30;
        final int EmailLocationY = 480;
        final int EmailWidth = 200;
        final int EmailHeight = 27;

        JLabel EmailBanner = new JLabel();

        // Email Banner (JLabel) Decorations.
        EmailBanner.setBounds(EmailLocationX, EmailLocationY, EmailWidth, EmailHeight);
        LeftPane.add(EmailBanner, new AbsoluteConstraints(EmailLocationX, EmailLocationY, EmailWidth, EmailHeight));
        EmailBanner.setForeground(new java.awt.Color(255, 255, 255));
        EmailBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        EmailBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        EmailBanner.setText("EMAIL");
        EmailBanner.setVisible(true);

        // Email Info (JLabel) Declarations.
        final int EmailInfoLocationX = 30;
        final int EmailInfoLocationY = 500;
        final int EmailInfoWidth = 300;
        final int EmailInfoHeight = 27;

        JLabel EmailInfo = new JLabel();

        // Email Info (JLabel) Decorations.
        EmailInfo.setBounds(EmailInfoLocationX, EmailInfoLocationY, EmailInfoWidth, EmailInfoHeight);
        LeftPane.add(EmailInfo, new AbsoluteConstraints(EmailInfoLocationX, EmailInfoLocationY, EmailInfoWidth, EmailInfoHeight));
        EmailInfo.setForeground(new java.awt.Color(255, 255, 255));
        EmailInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        EmailInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        EmailInfo.setText("jbb7102@gmail.com");
        EmailInfo.setVisible(true);

        // Left Pane Background (JLabel) Declarations.
        final int LPBackgroundHeight = 577;
        final int LPBackgroundWidth = 298;
        final int LPBackgroundLocationX = 0;
        final int LPBackgroundLocationY = 0;

        JLabel LPBackground = new JLabel();

        // Left Pane Background (JLabel) Decorations.
        LPBackground.setBounds(LPBackgroundLocationX, LPBackgroundLocationY, LPBackgroundWidth, LPBackgroundHeight);
        LeftPane.add(LPBackground, new AbsoluteConstraints(LPBackgroundLocationX, LPBackgroundLocationY, LPBackgroundWidth, LPBackgroundHeight));
        LPBackground.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LPBackground.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon LPBackgroundGetter = new ImageIcon("src\\res\\carbonbackgound.jpg");
        Image getBackground = LPBackgroundGetter.getImage();
        Image scaledBackground = getBackground.getScaledInstance(LPBackground.getWidth(), LPBackground.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayBackground = new ImageIcon(scaledBackground);
        LPBackground.setIcon(displayBackground);

        // JFrame Visibility
        mainFrame.setVisible(true);
    }

    static void MonResume() {

        final int MaxFrameSizeX = 1366;
        final int MaxFrameSizeY = 746;

        final int MinFrameSizeX = 1366;
        final int MinFrameSizeY = 746;

        JFrame mainFrame = new JFrame();

        // JFrame Size
        mainFrame.setSize(MinFrameSizeX, MinFrameSizeY);
        mainFrame.setMinimumSize(new java.awt.Dimension(MinFrameSizeX, MinFrameSizeY));
        mainFrame.setPreferredSize(new java.awt.Dimension(MaxFrameSizeX, MaxFrameSizeY));
        mainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //JFrame Decoration
        mainFrame.setUndecorated(false);
        mainFrame.setOpacity(1.0f);
        mainFrame.setTitle("COMPROG 3 : Activity 2 | Mon Resume.");
        mainFrame.setLayout(null);

        // CENTER POPUP MAIN WINDOW
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation(dimension.width / 2 - mainFrame.getWidth() / 2, dimension.height / 2 - mainFrame.getHeight() / 2);

        // JPanel titleBar 
        final int titleBarHeigth = 128;
        final int titleBarWidth = 1366;
        final int titleBarLocationX = 0;
        final int titleBarLocationY = 0;

        JPanel titleBar = new JPanel();

        // titleBar (JPanel) Decorations.
        titleBar.setBounds(titleBarLocationX, titleBarLocationY, titleBarWidth, titleBarHeigth);
        mainFrame.add(titleBar, new AbsoluteConstraints(titleBarLocationX, titleBarLocationY, titleBarWidth, titleBarHeigth));
        titleBar.setBackground(new java.awt.Color(0, 0, 35));
        titleBar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 208, 0), 2, false));
        titleBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Logo (JLabel) Declarations.
        final int logoHeight = 158;
        final int logoWidth = 158;
        final int logoLocationX = 350;
        final int logoLocationY = 5;

        JLabel logo = new JLabel();

        // Logo (JLabel) Decorations.
        logo.setBounds(logoLocationX, logoLocationY, logoWidth, logoHeight);
        titleBar.add(logo, new AbsoluteConstraints(logoLocationX, logoLocationY, logoWidth, logoHeight));
        logo.setForeground(new java.awt.Color(0, 0, 0));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon logoGetter = new ImageIcon("src\\res\\Brion-Tactical-Systems.png");
        Image getLogo = logoGetter.getImage();
        Image scaleLogo = getLogo.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayLogo = new ImageIcon(scaleLogo);
        logo.setIcon(displayLogo);

        // Logo Text (JLabel) Declarations.
        Font IronShark;

        final int companyNameHeight = 20;
        final int companyNameWidth = 600;
        final int companyNameLocationX = 470;
        final int companyNameLocationY = 50;

        JLabel companyName = new JLabel();

        final int cNameShadowLocationY = 54;

        JLabel cNameShadow = new JLabel();

        companyName.setBounds(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight);
        titleBar.add(companyName, new AbsoluteConstraints(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight));
        companyName.setForeground(new java.awt.Color(255, 208, 0));
        companyName.setFont(new java.awt.Font("Iron Shark", 0, 20));

        cNameShadow.setBounds(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight);
        titleBar.add(cNameShadow, new AbsoluteConstraints(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight));
        cNameShadow.setForeground(new java.awt.Color(0, 0, 0));
        cNameShadow.setFont(new java.awt.Font("Iron Shark", 0, 20));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        companyName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        companyName.setText("Brion Tactical Systems");
        companyName.setVisible(true);

        cNameShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cNameShadow.setText("Brion Tactical Systems");
        cNameShadow.setVisible(true);

        // Activity Title 
        final int mainTextHeight = 50;
        final int mainTextWidth = 600;
        final int mainTextX = 500;
        final int mainTextY = 60;

        JLabel mainText = new JLabel();

        mainText.setBounds(mainTextX, mainTextY, mainTextWidth, mainTextHeight);
        titleBar.add(mainText, new AbsoluteConstraints(mainTextX, mainTextY, mainTextWidth, mainTextHeight));
        mainText.setForeground(new java.awt.Color(255, 255, 255));
        mainText.setFont(new java.awt.Font("Tahoma", 1, 20));

        mainText.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        mainText.setText("JAVA SWING ACTIVITY #2 | GROUP 8 (MON RESUME)");
        mainText.setVisible(true);

        // Document (JPanel) Declarations.
        final int DocHeight = 579;
        final int DocWidth = 1366;
        final int DocLocationX = 0;
        final int DocLocationY = 128;

        JPanel Doc = new JPanel();

        // Document (JPanel) Decorations.
        Doc.setBounds(DocLocationX, DocLocationY, DocWidth, DocHeight);
        mainFrame.add(Doc, new AbsoluteConstraints(DocLocationX, DocLocationY, DocWidth, DocHeight));
        Doc.setBackground(new java.awt.Color(242, 204, 143));
        Doc.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 200, 0), 0, false));
        Doc.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Doc.setVisible(true);

        // Applicant's Name (JLabel) Declarations.
        final int nameLocationX = 550;
        final int nameLocationY = 20;
        final int nameWidth = 650;
        final int nameHeight = 45;

        JLabel name = new JLabel();

        // Applicant's Name (JLabel) Decorations.
        name.setBounds(nameLocationX, nameLocationY, nameWidth, nameHeight);
        Doc.add(name, new AbsoluteConstraints(nameLocationX, nameLocationY, nameWidth, nameHeight));
        name.setForeground(new java.awt.Color(0, 0, 0));
        name.setFont(new java.awt.Font("Times New Roman", 1, 60));

        name.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        name.setText("SHANE MARIE MON");
        name.setVisible(true);

        // Applicant's Job Role (JLabel) Declarations.
        final int jobRoleLocationX = 630;
        final int jobRoleLocationY = 80;
        final int jobRoleWidth = 600;
        final int jobRoleHeight = 20;

        JLabel jobRole = new JLabel();

        // Applicant's Job Role (JLabel) Decorations.
        jobRole.setBounds(jobRoleLocationX, jobRoleLocationY, jobRoleWidth, jobRoleHeight);
        Doc.add(jobRole, new AbsoluteConstraints(jobRoleLocationX, jobRoleLocationY, jobRoleWidth, jobRoleHeight));
        jobRole.setForeground(new java.awt.Color(0, 0, 0));
        jobRole.setFont(new java.awt.Font("Calibri", 0, 20));

        jobRole.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        jobRole.setText("JAVA SOFTWARE ENGINEER / SOFTWARE DEVELOPER");
        jobRole.setVisible(true);

        // Educational Background (JLabel) Declarations.
        final int EBackgroundLocationX = 320;
        final int EBackgroundLocationY = 140;
        final int EBackgroundWidth = 300;
        final int EBackgroundHeigth = 27;

        JLabel EBackground = new JLabel();

        // Educational Background (JLabel) Decorations.
        EBackground.setBounds(EBackgroundLocationX, EBackgroundLocationY, EBackgroundWidth, EBackgroundHeigth);
        Doc.add(EBackground, new AbsoluteConstraints(EBackgroundLocationX, EBackgroundLocationY, EBackgroundWidth, EBackgroundHeigth));
        EBackground.setForeground(new java.awt.Color(0, 0, 0));
        EBackground.setFont(new java.awt.Font("Times New Roman", 1, 18));

        EBackground.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EBackground.setText("EDUCATIONAL BACKGROUND");
        EBackground.setVisible(true);

        // Educational Background Informations.
        // Elementary Info (JLabel) Declarations.
        final int ElementaryLocationX = 320;
        final int ElementaryLocationY = 170;
        final int ElementaryWidth = 300;
        final int ElementaryHeight = 27;

        JLabel Elementary = new JLabel();

        // Elementary (JLabel) Decorations.
        Elementary.setBounds(ElementaryLocationX, ElementaryLocationY, ElementaryWidth, ElementaryHeight);
        Doc.add(Elementary, new AbsoluteConstraints(ElementaryLocationX, ElementaryLocationY, ElementaryWidth, ElementaryHeight));
        Elementary.setForeground(new java.awt.Color(0, 0, 0));
        Elementary.setFont(new java.awt.Font("Calibri", 0, 18));

        Elementary.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Elementary.setText("San Julian Elementary School");
        Elementary.setVisible(true);

        // Elementary Year (JLabel) Declarations.
        final int ElemSYLocationX = 320;
        final int ElemSYLocationY = 190;
        final int ElemSYWidth = 300;
        final int ElemSYHeight = 27;

        JLabel ElemSY = new JLabel();

        // Elementary Year (JLabel) Decorations.
        ElemSY.setBounds(ElemSYLocationX, ElemSYLocationY, ElemSYWidth, ElemSYHeight);
        Doc.add(ElemSY, new AbsoluteConstraints(ElemSYLocationX, ElemSYLocationY, ElemSYWidth, ElemSYHeight));
        ElemSY.setForeground(new java.awt.Color(0, 0, 0));
        ElemSY.setFont(new java.awt.Font("Calibri", 0, 16));

        ElemSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ElemSY.setText("S.Y 2006 - 2012 (Elementary)");
        ElemSY.setVisible(true);

        // Junior High School Info (JLabel) Declarations.
        final int JHSLocationX = 320;
        final int JHSLocationY = 230;
        final int JHSWidth = 300;
        final int JHSHeight = 27;

        JLabel JHS = new JLabel();

        // Junior High School Info (JLabel) Decorations.
        JHS.setBounds(JHSLocationX, JHSLocationY, JHSWidth, JHSHeight);
        Doc.add(JHS, new AbsoluteConstraints(JHSLocationX, JHSLocationY, JHSWidth, JHSHeight));
        JHS.setForeground(new java.awt.Color(0, 0, 0));
        JHS.setFont(new java.awt.Font("Calibri", 0, 18));

        JHS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JHS.setText("San Julian Sta. Maria High School");
        JHS.setVisible(true);

        // Senior High School Year (JLabel) Declarations.
        final int JHSSchoolYearLocationX = 320;
        final int JHSSchoolYearLocationY = 250;
        final int JHSSchoolYearWidth = 300;
        final int JHSSchoolYearHeight = 27;

        JLabel JuniorHighSchoolSY = new JLabel();

        // Senior High School Year (JLabel) Decorations.
        JuniorHighSchoolSY.setBounds(JHSSchoolYearLocationX, JHSSchoolYearLocationY, JHSSchoolYearWidth, JHSSchoolYearHeight);
        Doc.add(JuniorHighSchoolSY, new AbsoluteConstraints(JHSSchoolYearLocationX, JHSSchoolYearLocationY, JHSSchoolYearWidth, JHSSchoolYearHeight));
        JuniorHighSchoolSY.setForeground(new java.awt.Color(0, 0, 0));
        JuniorHighSchoolSY.setFont(new java.awt.Font("Calibri", 0, 16));

        JuniorHighSchoolSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JuniorHighSchoolSY.setText("S.Y 2016 - 2018 (Junior High School)");
        JuniorHighSchoolSY.setVisible(true);

        // Senior High School Info (JLabel) Declarations.
        final int SHSLocationX = 320;
        final int SHSLocationY = 290;
        final int SHSWidth = 300;
        final int SHSHeight = 27;

        JLabel SHS = new JLabel();

        // Senior High School Info (JLabel) Decorations.
        SHS.setBounds(SHSLocationX, SHSLocationY, SHSWidth, SHSHeight);
        Doc.add(SHS, new AbsoluteConstraints(SHSLocationX, SHSLocationY, SHSWidth, SHSHeight));
        SHS.setForeground(new java.awt.Color(0, 0, 0));
        SHS.setFont(new java.awt.Font("Calibri", 0, 18));

        SHS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SHS.setText("CIT Colleges Paniqui Foundation");
        SHS.setVisible(true);

        // Senior High School Year (JLabel) Declarations.
        final int SeniorHighSchoolSYLocationX = 320;
        final int SeniorHighSchoolSYLocationY = 310;
        final int SeniorHighSchoolSYWidth = 300;
        final int SeniorHighSchoolSYHeight = 27;

        JLabel SeniorHighSchoolSY = new JLabel();

        // High School Year (JLabel) Decorations.
        SeniorHighSchoolSY.setBounds(SeniorHighSchoolSYLocationX, SeniorHighSchoolSYLocationY, SeniorHighSchoolSYWidth, SeniorHighSchoolSYHeight);
        Doc.add(SeniorHighSchoolSY, new AbsoluteConstraints(SeniorHighSchoolSYLocationX, SeniorHighSchoolSYLocationY, SeniorHighSchoolSYWidth, SeniorHighSchoolSYHeight));
        SeniorHighSchoolSY.setForeground(new java.awt.Color(0, 0, 0));
        SeniorHighSchoolSY.setFont(new java.awt.Font("Calibri", 0, 16));

        SeniorHighSchoolSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SeniorHighSchoolSY.setText("S.Y 2018 - 2020 (Senior High School)");
        SeniorHighSchoolSY.setVisible(true);

        // College Scool Info (JLabel) Declarations.
        final int CollegeLocationX = 320;
        final int CollegeLocationY = 350;
        final int CollegeWidth = 300;
        final int CollegeHeight = 27;

        JLabel College = new JLabel();

        // College School Info (JLabel) Decorations.
        College.setBounds(CollegeLocationX, CollegeLocationY, CollegeWidth, CollegeHeight);
        Doc.add(College, new AbsoluteConstraints(CollegeLocationX, CollegeLocationY, CollegeWidth, CollegeHeight));
        College.setForeground(new java.awt.Color(0, 0, 0));
        College.setFont(new java.awt.Font("Calibri", 0, 18));

        College.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        College.setText("Tarlac State University");
        College.setVisible(true);

        // College School Year (JLabel) Declarations.
        final int CollegeSYLocationX = 320;
        final int CollegeSYLocationY = 370;
        final int CollegeSYWidth = 300;
        final int CollegeSYHeight = 27;

        JLabel CollegeSY = new JLabel();

        // College School Year (JLabel) Decorations.
        CollegeSY.setBounds(CollegeSYLocationX, CollegeSYLocationY, CollegeSYWidth, CollegeSYHeight);
        Doc.add(CollegeSY, new AbsoluteConstraints(CollegeSYLocationX, CollegeSYLocationY, CollegeSYWidth, CollegeSYHeight));
        CollegeSY.setForeground(new java.awt.Color(0, 0, 0));
        CollegeSY.setFont(new java.awt.Font("Calibri", 0, 16));

        CollegeSY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CollegeSY.setText("S.Y 2018 - Present (College)");
        CollegeSY.setVisible(true);

        // Skills Background (JLabel) Declarations.
        final int SkillsLocationX = 640;
        final int SkillsLocationY = 140;
        final int SkillsWidth = 300;
        final int SkillsHeigth = 27;

        JLabel Skills = new JLabel();

        // Skills Background (JLabel) Decorations.
        Skills.setBounds(SkillsLocationX, SkillsLocationY, SkillsWidth, SkillsHeigth);
        Doc.add(Skills, new AbsoluteConstraints(SkillsLocationX, SkillsLocationY, SkillsWidth, SkillsHeigth));
        Skills.setForeground(new java.awt.Color(0, 0, 0));
        Skills.setFont(new java.awt.Font("Times New Roman", 1, 18));

        Skills.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills.setText("SKILLS");
        Skills.setVisible(true);

        // Skills Info (JLabel) Declarations
        final int Skills1LocationX = 640;
        final int Skills1LocationY = 170;
        final int Skills1Width = 300;
        final int Skills1Height = 27;

        JLabel Skills1 = new JLabel();

        // Skills Info (JLabel) Decorations.
        Skills1.setBounds(Skills1LocationX, Skills1LocationY, Skills1Width, Skills1Height);
        Doc.add(Skills1, new AbsoluteConstraints(Skills1LocationX, Skills1LocationY, Skills1Width, Skills1Height));
        Skills1.setForeground(new java.awt.Color(0, 0, 0));
        Skills1.setFont(new java.awt.Font("Calibri", 0, 18));

        Skills1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills1.setText("Active Listener");
        Skills1.setVisible(true);

        // Skills Info 2 (JLabel) Declarations
        final int Skills2LocationX = 640;
        final int Skills2LocationY = 200;
        final int Skills2Width = 300;
        final int Skills2Height = 27;

        JLabel Skills2 = new JLabel();

        // Skills Info 2(JLabel) Decorations.
        Skills2.setBounds(Skills2LocationX, Skills2LocationY, Skills2Width, Skills2Height);
        Doc.add(Skills2, new AbsoluteConstraints(Skills2LocationX, Skills2LocationY, Skills2Width, Skills1Height));
        Skills2.setForeground(new java.awt.Color(0, 0, 0));
        Skills2.setFont(new java.awt.Font("Calibri", 0, 18));

        Skills2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Skills2.setText("Good Communication Skills");
        Skills2.setVisible(true);

        // Favorites Background (JLabel) Declarations.
        final int FavoritesLocationX = 950;
        final int FavoritesLocationY = 140;
        final int FavoritesWidth = 300;
        final int FavoritesHeigth = 27;

        JLabel Favorites = new JLabel();

        // Favorites Background (JLabel) Decorations.
        Favorites.setBounds(FavoritesLocationX, FavoritesLocationY, FavoritesWidth, FavoritesHeigth);
        Doc.add(Favorites, new AbsoluteConstraints(FavoritesLocationX, FavoritesLocationY, FavoritesWidth, FavoritesHeigth));
        Favorites.setForeground(new java.awt.Color(0, 0, 0));
        Favorites.setFont(new java.awt.Font("Times New Roman", 1, 18));

        Favorites.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Favorites.setText("FAVORITES");
        Favorites.setVisible(true);

        // Favorites Info 1 (JLabel) Declarations
        final int Favorites1LocationX = 950;
        final int Favorites1LocationY = 170;
        final int Favorites1Width = 300;
        final int Favorites1Height = 27;

        JLabel Favorites1 = new JLabel();

        // Favorites Info 1 (JLabel) Decorations.
        Favorites1.setBounds(Favorites1LocationX, Favorites1LocationY, Favorites1Width, Favorites1Height);
        Doc.add(Favorites1, new AbsoluteConstraints(Favorites1LocationX, Favorites1LocationY, Favorites1Width, Favorites1Height));
        Favorites1.setForeground(new java.awt.Color(0, 0, 0));
        Favorites1.setFont(new java.awt.Font("Calibri", 0, 18));

        Favorites1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Favorites1.setText("Playing Online Games");
        Favorites1.setVisible(true);

        // Favorites Info 2 (JLabel) Declarations
        final int Favorites2LocationX = 950;
        final int Favorites2LocationY = 200;
        final int Favorites2Width = 300;
        final int Favorites2Height = 27;

        JLabel Favorites2 = new JLabel();

        // Favorites Info 2 (JLabel) Decorations.
        Favorites2.setBounds(Favorites2LocationX, Favorites2LocationY, Favorites2Width, Favorites2Height);
        Doc.add(Favorites2, new AbsoluteConstraints(Favorites2LocationX, Favorites2LocationY, Favorites2Width, Favorites2Height));
        Favorites2.setForeground(new java.awt.Color(0, 0, 0));
        Favorites2.setFont(new java.awt.Font("Calibri", 0, 18));

        Favorites2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Favorites2.setText("Watching K-Drama (Series/Movie)");
        Favorites2.setVisible(true);

        // Left Pane (JPanel) Declarations.
        final int LeftPaneHeight = 579;
        final int LeftPaneWidth = 300;
        final int LeftPaneLocationX = 0;
        final int LeftPaneLocationY = 0;

        JPanel LeftPane = new JPanel();

        // Left Pane (JPanel) Decorations.
        LeftPane.setBounds(LeftPaneLocationX, LeftPaneLocationY, LeftPaneWidth, LeftPaneHeight);
        Doc.add(LeftPane, new AbsoluteConstraints(LeftPaneLocationX, LeftPaneLocationY, LeftPaneWidth, LeftPaneHeight));
        LeftPane.setBackground(new java.awt.Color(0, 0, 0));
        LeftPane.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(224, 122, 95), 2, false));
        LeftPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        LeftPane.setVisible(true);

        // Picture Frame (JPanel) Declarations.
        final int pictureFrameHeigth = 200;
        final int pictureFrameWidth = 200;
        final int pictureFrameLocationX = 50;
        final int pictureFrameLocationY = 10;

        JPanel pictureFrame = new JPanel();

        // Picture Frame (JPanel) Decorations.
        pictureFrame.setBounds(pictureFrameLocationX, pictureFrameLocationY, pictureFrameWidth, pictureFrameHeigth);
        LeftPane.add(pictureFrame, new AbsoluteConstraints(pictureFrameLocationX, pictureFrameLocationY, pictureFrameWidth, pictureFrameHeigth));
        pictureFrame.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(224, 122, 95), 2, false));
        pictureFrame.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Picture (JLabel) Declarations.
        final int pictureHeight = 196;
        final int pictureWidth = 196;
        final int pictureLocationX = 2;
        final int pictureLocationY = 2;

        JLabel picture = new JLabel();

        // Picture (JLabel) Decorations;
        picture.setBounds(pictureLocationX, pictureLocationY, pictureWidth, pictureHeight);
        pictureFrame.add(picture, new AbsoluteConstraints(pictureLocationX, pictureLocationY, pictureWidth, pictureHeight));
        picture.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picture.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon pictureGetter = new ImageIcon("src\\res\\MonPicture.jpg");
        Image getPicture = pictureGetter.getImage();
        Image scaledPicture = getPicture.getScaledInstance(picture.getWidth(), picture.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayPicture = new ImageIcon(scaledPicture);
        picture.setIcon(displayPicture);

        // Personal Information Banner (JPanel) Declarations.
        final int personalInfoLocationX = 50;
        final int perosnalInfoLocationY = 230;
        final int personalInfoWidth = 252;
        final int personalInfoHeight = 30;

        JPanel personalInfo = new JPanel();

        // Personal Information Banner (JPanel) Decorations.
        personalInfo.setBounds(personalInfoLocationX, perosnalInfoLocationY, personalInfoWidth, personalInfoHeight);
        LeftPane.add(personalInfo, new AbsoluteConstraints(personalInfoLocationX, perosnalInfoLocationY, personalInfoWidth, personalInfoHeight));
        personalInfo.setBackground(new java.awt.Color(242, 204, 143));
        personalInfo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(224, 122, 95), 2, false));
        personalInfo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        personalInfo.setVisible(true);

        // Personal Information Banner Text (JPanel) Declarations.
        final int personalInfoTextLocationX = 12;
        final int personalInfoTextLocationY = 2;
        final int personalInfoTextWidth = 248;
        final int personalInfoTextHeight = 27;

        JLabel personalInfoText = new JLabel();

        // Personal Information Banner Text (JPanel) Decorations.
        personalInfoText.setBounds(personalInfoTextLocationX, personalInfoTextLocationY, personalInfoTextWidth, personalInfoTextHeight);
        personalInfo.add(personalInfoText, new AbsoluteConstraints(personalInfoTextLocationX, personalInfoTextLocationY, personalInfoTextWidth, personalInfoTextHeight));
        personalInfoText.setForeground(new java.awt.Color(0, 0, 0));
        personalInfoText.setFont(new java.awt.Font("Times New Roman", 1, 18));

        personalInfoText.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        personalInfoText.setText("PERSONAL INFORMATION");
        personalInfoText.setVisible(true);

        // Address (JLabel) Declarations.
        final int AddressBannerLocationX = 30;
        final int AddressBannerLocationY = 260;
        final int AddressBannerWidth = 200;
        final int AddressBannerHeight = 27;

        JLabel addressBanner = new JLabel();

        // Address (JLabel) Decorations.
        addressBanner.setBounds(AddressBannerLocationX, AddressBannerLocationY, AddressBannerWidth, AddressBannerHeight);
        LeftPane.add(addressBanner, new AbsoluteConstraints(AddressBannerLocationX, AddressBannerLocationY, AddressBannerWidth, AddressBannerHeight));
        addressBanner.setForeground(new java.awt.Color(255, 255, 255));
        addressBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        addressBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        addressBanner.setText("ADDRESS");
        addressBanner.setVisible(true);

        // Address Info (JLabel) Declarations.
        final int AddressInfoLocationX = 30;
        final int AddressInfoLocationY = 280;
        final int AddressInfoWidth = 300;
        final int AddressInfoHeight = 27;

        JLabel AddressInfo = new JLabel();

        // Address Indo (JLabel) Decorations.
        AddressInfo.setBounds(AddressInfoLocationX, AddressInfoLocationY, AddressInfoWidth, AddressInfoHeight);
        LeftPane.add(AddressInfo, new AbsoluteConstraints(AddressInfoLocationX, AddressInfoLocationY, AddressInfoWidth, AddressInfoHeight));
        AddressInfo.setForeground(new java.awt.Color(255, 255, 255));
        AddressInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        AddressInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        AddressInfo.setText("#052 Rodrigues Street, Brgy.Sta.Maria,");
        AddressInfo.setVisible(true);

        // Address Info2 (JLabel) Declarations.
        final int AddressInfo2LocationX = 30;
        final int AddressInfo2LocationY = 300;
        final int AddressInfo2Width = 300;
        final int AddressInfo2Height = 27;

        JLabel AddressInfo2 = new JLabel();

        // Address Indo2 (JLabel) Decorations.
        AddressInfo2.setBounds(AddressInfo2LocationX, AddressInfo2LocationY, AddressInfo2Width, AddressInfo2Height);
        LeftPane.add(AddressInfo2, new AbsoluteConstraints(AddressInfo2LocationX, AddressInfo2LocationY, AddressInfo2Width, AddressInfo2Height));
        AddressInfo2.setForeground(new java.awt.Color(255, 255, 255));
        AddressInfo2.setFont(new java.awt.Font("Calibri", 0, 14));

        AddressInfo2.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        AddressInfo2.setText("Moncada, Tarlac");
        AddressInfo2.setVisible(true);

        // Birthdate (JLabel) Declarations.
        final int BirthdateBannerLocationX = 30;
        final int BirthdateBannerLocationY = 320;
        final int BirthdateBannerWidth = 200;
        final int BirthdateBannerHeight = 27;

        JLabel BirthdateBanner = new JLabel();

        // Birthdate (JLabel) Decorations.
        BirthdateBanner.setBounds(BirthdateBannerLocationX, BirthdateBannerLocationY, BirthdateBannerWidth, BirthdateBannerHeight);
        LeftPane.add(BirthdateBanner, new AbsoluteConstraints(BirthdateBannerLocationX, BirthdateBannerLocationY, BirthdateBannerWidth, BirthdateBannerHeight));
        BirthdateBanner.setForeground(new java.awt.Color(255, 255, 255));
        BirthdateBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        BirthdateBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        BirthdateBanner.setText("BIRTHDATE");
        BirthdateBanner.setVisible(true);

        // Birthdate Info (JLabel) Declarations.
        final int BirthdateInfoLocationX = 30;
        final int BirthdateInfoLocationY = 340;
        final int BirthdateInfoWidth = 300;
        final int BirthdateInfoHeight = 27;

        JLabel BirthdateInfo = new JLabel();

        // Birthdate Indo (JLabel) Decorations.
        BirthdateInfo.setBounds(BirthdateInfoLocationX, BirthdateInfoLocationY, BirthdateInfoWidth, BirthdateInfoHeight);
        LeftPane.add(BirthdateInfo, new AbsoluteConstraints(BirthdateInfoLocationX, BirthdateInfoLocationY, BirthdateInfoWidth, BirthdateInfoHeight));
        BirthdateInfo.setForeground(new java.awt.Color(255, 255, 255));
        BirthdateInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        BirthdateInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        BirthdateInfo.setText("December 7, 2000");
        BirthdateInfo.setVisible(true);

        // Citizenship (JLabel) Declarations.
        final int CitizenshipBannerLocationX = 30;
        final int CitizenshipBannerLocationY = 360;
        final int CitizenshipBannerWidth = 200;
        final int CitizenshipBannerHeight = 27;

        JLabel CitizenshipBanner = new JLabel();

        // Citizenship Banner (JLabel) Decorations.
        CitizenshipBanner.setBounds(CitizenshipBannerLocationX, CitizenshipBannerLocationY, CitizenshipBannerWidth, CitizenshipBannerHeight);
        LeftPane.add(CitizenshipBanner, new AbsoluteConstraints(CitizenshipBannerLocationX, CitizenshipBannerLocationY, CitizenshipBannerWidth, CitizenshipBannerHeight));
        CitizenshipBanner.setForeground(new java.awt.Color(255, 255, 255));
        CitizenshipBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        CitizenshipBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        CitizenshipBanner.setText("CITIZENSHIP");
        CitizenshipBanner.setVisible(true);

        // Citizenship Info (JLabel) Declarations.
        final int CitizenshipInfoLocationX = 30;
        final int CitizenshipInfoLocationY = 380;
        final int CitizenshipInfoWidth = 300;
        final int CitizenshipInfoHeight = 27;

        JLabel CitizenshipInfo = new JLabel();

        // Citizenship Info (JLabel) Decorations.
        CitizenshipInfo.setBounds(CitizenshipInfoLocationX, CitizenshipInfoLocationY, CitizenshipInfoWidth, CitizenshipInfoHeight);
        LeftPane.add(CitizenshipInfo, new AbsoluteConstraints(CitizenshipInfoLocationX, CitizenshipInfoLocationY, CitizenshipInfoWidth, CitizenshipInfoHeight));
        CitizenshipInfo.setForeground(new java.awt.Color(255, 255, 255));
        CitizenshipInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        CitizenshipInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        CitizenshipInfo.setText("Filipino");
        CitizenshipInfo.setVisible(true);

        // Religion (JLabel) Declarations.
        final int ReligionBannerLocationX = 30;
        final int ReligionBannerLocationY = 400;
        final int ReligionBannerWidth = 200;
        final int ReligionBannerHeight = 27;

        JLabel ReligionBanner = new JLabel();

        // Religion Banner (JLabel) Decorations.
        ReligionBanner.setBounds(ReligionBannerLocationX, ReligionBannerLocationY, ReligionBannerWidth, ReligionBannerHeight);
        LeftPane.add(ReligionBanner, new AbsoluteConstraints(ReligionBannerLocationX, ReligionBannerLocationY, ReligionBannerWidth, ReligionBannerHeight));
        ReligionBanner.setForeground(new java.awt.Color(255, 255, 255));
        ReligionBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        ReligionBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ReligionBanner.setText("RELIGION");
        ReligionBanner.setVisible(true);

        // Religion Info (JLabel) Declarations.
        final int ReligionInfoLocationX = 30;
        final int ReligionInfoLocationY = 420;
        final int ReligionInfoWidth = 300;
        final int ReligionInfoHeight = 27;

        JLabel ReligionInfo = new JLabel();

        // Religion Info (JLabel) Decorations.
        ReligionInfo.setBounds(ReligionInfoLocationX, ReligionInfoLocationY, ReligionInfoWidth, ReligionInfoHeight);
        LeftPane.add(ReligionInfo, new AbsoluteConstraints(ReligionInfoLocationX, ReligionInfoLocationY, ReligionInfoWidth, ReligionInfoHeight));
        ReligionInfo.setForeground(new java.awt.Color(255, 255, 255));
        ReligionInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        ReligionInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ReligionInfo.setText("Catholic");
        ReligionInfo.setVisible(true);

        // Contacts (JLabel) Declarations.
        final int ContactBannerLocationX = 30;
        final int ContactBannerLocationY = 440;
        final int ContactBannerWidth = 200;
        final int ContactBannerHeight = 27;

        JLabel ContactsBanner = new JLabel();

        // Contacts Banner (JLabel) Decorations.
        ContactsBanner.setBounds(ContactBannerLocationX, ContactBannerLocationY, ContactBannerWidth, ContactBannerHeight);
        LeftPane.add(ContactsBanner, new AbsoluteConstraints(ContactBannerLocationX, ContactBannerLocationY, ReligionBannerWidth, ContactBannerHeight));
        ContactsBanner.setForeground(new java.awt.Color(255, 255, 255));
        ContactsBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        ContactsBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ContactsBanner.setText("CONTACTS");
        ContactsBanner.setVisible(true);

        // Contacts Info (JLabel) Declarations.
        final int ContactsInfoLocationX = 30;
        final int ContactsInfoLocationY = 460;
        final int ContactsInfoWidth = 300;
        final int ContactsInfoHeight = 27;

        JLabel ContactsInfo = new JLabel();

        // Contacts Info (JLabel) Decorations.
        ContactsInfo.setBounds(ContactsInfoLocationX, ContactsInfoLocationY, ContactsInfoWidth, ContactsInfoHeight);
        LeftPane.add(ContactsInfo, new AbsoluteConstraints(ContactsInfoLocationX, ContactsInfoLocationY, ContactsInfoWidth, ContactsInfoHeight));
        ContactsInfo.setForeground(new java.awt.Color(255, 255, 255));
        ContactsInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        ContactsInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ContactsInfo.setText("0916-7576-733");
        ContactsInfo.setVisible(true);

        // Email (JLabel) Declarations.
        final int EmailLocationX = 30;
        final int EmailLocationY = 480;
        final int EmailWidth = 200;
        final int EmailHeight = 27;

        JLabel EmailBanner = new JLabel();

        // Email Banner (JLabel) Decorations.
        EmailBanner.setBounds(EmailLocationX, EmailLocationY, EmailWidth, EmailHeight);
        LeftPane.add(EmailBanner, new AbsoluteConstraints(EmailLocationX, EmailLocationY, EmailWidth, EmailHeight));
        EmailBanner.setForeground(new java.awt.Color(255, 255, 255));
        EmailBanner.setFont(new java.awt.Font("Times New Roman", 1, 14));

        EmailBanner.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        EmailBanner.setText("EMAIL");
        EmailBanner.setVisible(true);

        // Email Info (JLabel) Declarations.
        final int EmailInfoLocationX = 30;
        final int EmailInfoLocationY = 500;
        final int EmailInfoWidth = 300;
        final int EmailInfoHeight = 27;

        JLabel EmailInfo = new JLabel();

        // Email Info (JLabel) Decorations.
        EmailInfo.setBounds(EmailInfoLocationX, EmailInfoLocationY, EmailInfoWidth, EmailInfoHeight);
        LeftPane.add(EmailInfo, new AbsoluteConstraints(EmailInfoLocationX, EmailInfoLocationY, EmailInfoWidth, EmailInfoHeight));
        EmailInfo.setForeground(new java.awt.Color(255, 255, 255));
        EmailInfo.setFont(new java.awt.Font("Calibri", 0, 14));

        EmailInfo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        EmailInfo.setText("shanemariemon32@gmail.com");
        EmailInfo.setVisible(true);

        // Left Pane Background (JLabel) Declarations.
        final int LPBackgroundHeight = 577;
        final int LPBackgroundWidth = 298;
        final int LPBackgroundLocationX = 0;
        final int LPBackgroundLocationY = 0;

        JLabel LPBackground = new JLabel();

        // Left Pane Background (JLabel) Decorations.
        LPBackground.setBounds(LPBackgroundLocationX, LPBackgroundLocationY, LPBackgroundWidth, LPBackgroundHeight);
        LeftPane.add(LPBackground, new AbsoluteConstraints(LPBackgroundLocationX, LPBackgroundLocationY, LPBackgroundWidth, LPBackgroundHeight));
        LPBackground.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LPBackground.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon LPBackgroundGetter = new ImageIcon("src\\res\\carbonbackgound.jpg");
        Image getBackground = LPBackgroundGetter.getImage();
        Image scaledBackground = getBackground.getScaledInstance(LPBackground.getWidth(), LPBackground.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayBackground = new ImageIcon(scaledBackground);
        LPBackground.setIcon(displayBackground);

        // JFrame Visibility
        mainFrame.setVisible(true);
    }

    public static void main(String[] args) {
        BrionResume();
        MonResume();
    }

}
