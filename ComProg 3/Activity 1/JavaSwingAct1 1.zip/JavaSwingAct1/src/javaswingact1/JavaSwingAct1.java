package javaswingact1;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.netbeans.lib.awtextra.AbsoluteConstraints;

public class JavaSwingAct1 {

    static void exitOperation() {

        final int MaxFrameSizeX = 600;
        final int MaxFrameSizeY = 400;

        final int MinFrameSizeX = 600;
        final int MinFrameSizeY = 400;

        JFrame mainFrame = new JFrame();

        // JFrame Size
        mainFrame.setSize(MinFrameSizeX, MinFrameSizeY);
        mainFrame.setMinimumSize(new java.awt.Dimension(MinFrameSizeX, MinFrameSizeY));
        mainFrame.setPreferredSize(new java.awt.Dimension(MaxFrameSizeX, MaxFrameSizeY));
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //JFrame Decoration
        mainFrame.setUndecorated(false);
        mainFrame.setOpacity(1.0f);
        mainFrame.setTitle("COMPROG 3 : Activity 1.1 | JFrame.EXIT_ON_CLOSE.");
        mainFrame.setLayout(null);

        // CENTER POPUP MAIN WINDOW
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation(dimension.width / 2 - mainFrame.getWidth() / 2, dimension.height / 2 - mainFrame.getHeight() / 2);

        // JPanel Background 
        final int BackgroundHeigth = 361;
        final int BackgroundWidth = 584;
        final int BackgroundPanelLocationX = 0;
        final int BackgroundPanelLocationY = 0;

        JPanel Background = new JPanel();

        // Background (JPanel) Decorations.
        Background.setBounds(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth);
        mainFrame.add(Background, new AbsoluteConstraints(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth));
        Background.setBackground(new java.awt.Color(0, 0, 32));
        Background.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 200, 0), 2, false));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Logo (JLabel) Declarations.
        final int logoHeight = 158;
        final int logoWidth = 158;
        final int logoLocationX = 5;
        final int logoLocationY = 5;

        JLabel logo = new JLabel();

        // Logo (JLabel) Decorations.
        logo.setBounds(logoLocationX, logoLocationY, logoWidth, logoHeight);
        Background.add(logo, new AbsoluteConstraints(logoLocationX, logoLocationY, logoWidth, logoHeight));
        logo.setForeground(new java.awt.Color(0, 0, 0));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon logoGetter = new ImageIcon("src\\res\\Brion-Tactical-Systems.png");
        Image getLogo = logoGetter.getImage();
        Image scaleLogo = getLogo.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayLogo = new ImageIcon(scaleLogo);
        logo.setIcon(displayLogo);

        // Logo Text (JLabel) Declarations.
        Font IronShark;

        final int companyNameHeight = 20;
        final int companyNameWidth = 600;
        final int companyNameLocationX = 50;
        final int companyNameLocationY = 50;

        JLabel companyName = new JLabel();

        final int cNameShadowLocationY = 54;

        JLabel cNameShadow = new JLabel();

        companyName.setBounds(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight);
        Background.add(companyName, new AbsoluteConstraints(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight));
        companyName.setForeground(new java.awt.Color(255, 208, 0));
        companyName.setFont(new java.awt.Font("Iron Shark", 0, 20));

        cNameShadow.setBounds(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight);
        Background.add(cNameShadow, new AbsoluteConstraints(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight));
        cNameShadow.setForeground(new java.awt.Color(0, 0, 0));
        cNameShadow.setFont(new java.awt.Font("Iron Shark", 0, 20));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        companyName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        companyName.setText("Brion Tactical Systems");
        companyName.setVisible(true);

        cNameShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cNameShadow.setText("Brion Tactical Systems");
        cNameShadow.setVisible(true);

        // Activity Title 
        final int mainTextHeight = 50;
        final int mainTextWidth = 400;
        final int mainTextX = 140;
        final int mainTextY = 60;

        JLabel mainText = new JLabel();

        mainText.setBounds(mainTextX, mainTextY, mainTextWidth, mainTextHeight);
        Background.add(mainText, new AbsoluteConstraints(mainTextX, mainTextY, mainTextWidth, mainTextHeight));
        mainText.setForeground(new java.awt.Color(255, 255, 255));
        mainText.setFont(new java.awt.Font("Tahoma", 1, 20));
        mainText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mainText.setText("JAVA SWING ACTIVITY #1 | GROUP 8");
        mainText.setVisible(true);

        // Students, Sections, Date Declarations.
        final int studentNameHeight = 40;
        final int studentNameWidth = 300;
        final int studentNameTextX = 20;
        final int studentNameTextY = 120;

        JLabel studentName = new JLabel();

        studentName.setBounds(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight);
        Background.add(studentName, new AbsoluteConstraints(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight));
        studentName.setForeground(new java.awt.Color(255, 255, 255));
        studentName.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentName.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentName.setText("Name : Jhon Brix Brion | M");
        studentName.setVisible(true);

        final int studentPairHeight = 40;
        final int studentPairWidth = 300;
        final int studentPairTextX = 20;
        final int studentPairTextY = 140;

        JLabel studentPair = new JLabel();

        studentPair.setBounds(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight);
        Background.add(studentPair, new AbsoluteConstraints(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight));
        studentPair.setForeground(new java.awt.Color(255, 255, 255));
        studentPair.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentPair.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentPair.setText("Pair : Shane Marie Mon | F");
        studentPair.setVisible(true);

        final int dateCreatedHeight = 40;
        final int dateCreatedWidth = 300;
        final int dateCreatedTextX = 310;
        final int dateCreatedTextY = 120;

        JLabel dateCreated = new JLabel();

        dateCreated.setBounds(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight);
        Background.add(dateCreated, new AbsoluteConstraints(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight));
        dateCreated.setForeground(new java.awt.Color(255, 255, 255));
        dateCreated.setFont(new java.awt.Font("Tahoma", 1, 16));
        dateCreated.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        dateCreated.setText("Date Created : February 4 2022");
        dateCreated.setVisible(true);

        final int subjectHeight = 40;
        final int subjectWidth = 300;
        final int subjectTextX = 310;
        final int subjectTextY = 140;

        JLabel subject = new JLabel();

        subject.setBounds(subjectTextX, subjectTextY, subjectWidth, subjectHeight);
        Background.add(subject, new AbsoluteConstraints(subjectTextX, subjectTextY, subjectWidth, subjectHeight));
        subject.setForeground(new java.awt.Color(255, 255, 255));
        subject.setFont(new java.awt.Font("Tahoma", 1, 16));
        subject.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        subject.setText("Subject : COMPROG 3");
        subject.setVisible(true);

        // Default Close Operation Label Declarations.
        final int defaultCloseOperationHeight = 40;
        final int defaultCloseOperationWidth = 500;
        final int defaultCloseOperationTextX = 70;
        final int defaultCloseOperationTextY = 190;

        JLabel defaultCloseOperation = new JLabel();

        defaultCloseOperation.setBounds(defaultCloseOperationTextX, defaultCloseOperationTextY, defaultCloseOperationWidth,
                defaultCloseOperationHeight);
        Background.add(defaultCloseOperation, new AbsoluteConstraints(defaultCloseOperationTextX, defaultCloseOperationTextY,
                defaultCloseOperationWidth, defaultCloseOperationHeight));
        defaultCloseOperation.setForeground(new java.awt.Color(255, 255, 255));
        defaultCloseOperation.setFont(new java.awt.Font("Tahoma", 1, 16));
        defaultCloseOperation.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        defaultCloseOperation.setText("Frame.DefaultCloseOperation(JFrame.EXIT_ON_CLOSE)");
        defaultCloseOperation.setVisible(true);

        // Hint Declarations.
        final int hintHeight = 40;
        final int hintWidth = 500;
        final int hintTextX = 70;
        final int hintTextY = 210;

        JLabel hint = new JLabel();

        hint.setBounds(hintTextX, hintTextY, hintWidth, hintHeight);
        Background.add(hint, new AbsoluteConstraints(hintTextX, hintTextY, hintWidth, hintHeight));
        hint.setForeground(new java.awt.Color(255, 255, 255));
        hint.setFont(new java.awt.Font("Tahoma", 1, 12));
        hint.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        hint.setText("Hint : Closes all processes (JFrames)");
        hint.setVisible(true);

        // HELLO WORLD (JLabel) Declarations.
        final int helloWorldHeight = 38;
        final int helloWorldWidth = 550;
        final int helloWorldLocationX = 20;
        final int helloWorldLocationY = 260;

        JLabel helloWorld = new JLabel();

        final int helloWorldShadowLocationY = 265;

        JLabel helloWorldShadow = new JLabel();

        helloWorld.setBounds(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorld, new AbsoluteConstraints(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight));
        helloWorld.setForeground(new java.awt.Color(255, 208, 0));
        helloWorld.setFont(new java.awt.Font("Iron Shark", 0, 50));

        helloWorldShadow.setBounds(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorldShadow, new AbsoluteConstraints(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight));
        helloWorldShadow.setForeground(new java.awt.Color(0, 0, 0));
        helloWorldShadow.setFont(new java.awt.Font("Iron Shark", 0, 50));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        helloWorld.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorld.setText("Hello World");
        helloWorld.setVisible(true);

        helloWorldShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorldShadow.setText("Hello World");
        helloWorldShadow.setVisible(true);

        // JFrame Visibility
        mainFrame.setVisible(true);
    }

    static void HIDEOperation() {

        final int MaxFrameSizeX = 600;
        final int MaxFrameSizeY = 400;

        final int MinFrameSizeX = 600;
        final int MinFrameSizeY = 400;

        JFrame mainFrame = new JFrame();

        // JFrame Size
        mainFrame.setSize(MinFrameSizeX, MinFrameSizeY);
        mainFrame.setMinimumSize(new java.awt.Dimension(MinFrameSizeX, MinFrameSizeY));
        mainFrame.setPreferredSize(new java.awt.Dimension(MaxFrameSizeX, MaxFrameSizeY));
        mainFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        //JFrame Decoration
        mainFrame.setUndecorated(false);
        mainFrame.setOpacity(1.0f);
        mainFrame.setTitle("COMPROG 3 : Activity 1.2 | JFrame.HIDE_ON_CLOSE.");
        mainFrame.setLayout(null);

        // CENTER POPUP MAIN WINDOW
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation(dimension.width / 2 - mainFrame.getWidth() / 2, dimension.height / 2 - mainFrame.getHeight() / 2);

        // JPanel Background 
        final int BackgroundHeigth = 361;
        final int BackgroundWidth = 584;
        final int BackgroundPanelLocationX = 0;
        final int BackgroundPanelLocationY = 0;

        JPanel Background = new JPanel();

        // Background (JPanel) Decorations.
        Background.setBounds(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth);
        mainFrame.add(Background, new AbsoluteConstraints(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth));
        Background.setBackground(new java.awt.Color(0, 0, 32));
        Background.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 200, 0), 2, false));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Logo (JLabel) Declarations.
        final int logoHeight = 158;
        final int logoWidth = 158;
        final int logoLocationX = 5;
        final int logoLocationY = 5;

        JLabel logo = new JLabel();

        // Logo (JLabel) Decorations.
        logo.setBounds(logoLocationX, logoLocationY, logoWidth, logoHeight);
        Background.add(logo, new AbsoluteConstraints(logoLocationX, logoLocationY, logoWidth, logoHeight));
        logo.setForeground(new java.awt.Color(0, 0, 0));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon logoGetter = new ImageIcon("src\\res\\Brion-Tactical-Systems.png");
        Image getLogo = logoGetter.getImage();
        Image scaleLogo = getLogo.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayLogo = new ImageIcon(scaleLogo);
        logo.setIcon(displayLogo);

        // Logo Text (JLabel) Declarations.
        Font IronShark;

        final int companyNameHeight = 20;
        final int companyNameWidth = 600;
        final int companyNameLocationX = 50;
        final int companyNameLocationY = 50;

        JLabel companyName = new JLabel();

        final int cNameShadowLocationY = 54;

        JLabel cNameShadow = new JLabel();

        companyName.setBounds(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight);
        Background.add(companyName, new AbsoluteConstraints(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight));
        companyName.setForeground(new java.awt.Color(255, 208, 0));
        companyName.setFont(new java.awt.Font("Iron Shark", 0, 20));

        cNameShadow.setBounds(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight);
        Background.add(cNameShadow, new AbsoluteConstraints(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight));
        cNameShadow.setForeground(new java.awt.Color(0, 0, 0));
        cNameShadow.setFont(new java.awt.Font("Iron Shark", 0, 20));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        companyName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        companyName.setText("Brion Tactical Systems");
        companyName.setVisible(true);

        cNameShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cNameShadow.setText("Brion Tactical Systems");
        cNameShadow.setVisible(true);

        // Activity Title 
        final int mainTextHeight = 50;
        final int mainTextWidth = 400;
        final int mainTextX = 140;
        final int mainTextY = 60;

        JLabel mainText = new JLabel();

        mainText.setBounds(mainTextX, mainTextY, mainTextWidth, mainTextHeight);
        Background.add(mainText, new AbsoluteConstraints(mainTextX, mainTextY, mainTextWidth, mainTextHeight));
        mainText.setForeground(new java.awt.Color(255, 255, 255));
        mainText.setFont(new java.awt.Font("Tahoma", 1, 20));
        mainText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mainText.setText("JAVA SWING ACTIVITY #1 | GROUP 8");
        mainText.setVisible(true);

        // Students, Sections, Date Declarations.
        final int studentNameHeight = 40;
        final int studentNameWidth = 300;
        final int studentNameTextX = 20;
        final int studentNameTextY = 120;

        JLabel studentName = new JLabel();

        studentName.setBounds(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight);
        Background.add(studentName, new AbsoluteConstraints(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight));
        studentName.setForeground(new java.awt.Color(255, 255, 255));
        studentName.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentName.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentName.setText("Name : Jhon Brix Brion | M");
        studentName.setVisible(true);

        final int studentPairHeight = 40;
        final int studentPairWidth = 300;
        final int studentPairTextX = 20;
        final int studentPairTextY = 140;

        JLabel studentPair = new JLabel();

        studentPair.setBounds(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight);
        Background.add(studentPair, new AbsoluteConstraints(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight));
        studentPair.setForeground(new java.awt.Color(255, 255, 255));
        studentPair.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentPair.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentPair.setText("Pair : Shane Marie Mon | F");
        studentPair.setVisible(true);

        final int dateCreatedHeight = 40;
        final int dateCreatedWidth = 300;
        final int dateCreatedTextX = 310;
        final int dateCreatedTextY = 120;

        JLabel dateCreated = new JLabel();

        dateCreated.setBounds(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight);
        Background.add(dateCreated, new AbsoluteConstraints(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight));
        dateCreated.setForeground(new java.awt.Color(255, 255, 255));
        dateCreated.setFont(new java.awt.Font("Tahoma", 1, 16));
        dateCreated.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        dateCreated.setText("Date Created : February 4 2022");
        dateCreated.setVisible(true);

        final int subjectHeight = 40;
        final int subjectWidth = 300;
        final int subjectTextX = 310;
        final int subjectTextY = 140;

        JLabel subject = new JLabel();

        subject.setBounds(subjectTextX, subjectTextY, subjectWidth, subjectHeight);
        Background.add(subject, new AbsoluteConstraints(subjectTextX, subjectTextY, subjectWidth, subjectHeight));
        subject.setForeground(new java.awt.Color(255, 255, 255));
        subject.setFont(new java.awt.Font("Tahoma", 1, 16));
        subject.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        subject.setText("Subject : COMPROG 3");
        subject.setVisible(true);

        // Default Close Operation Label Declarations.
        final int defaultCloseOperationHeight = 40;
        final int defaultCloseOperationWidth = 500;
        final int defaultCloseOperationTextX = 70;
        final int defaultCloseOperationTextY = 190;

        JLabel defaultCloseOperation = new JLabel();

        defaultCloseOperation.setBounds(defaultCloseOperationTextX, defaultCloseOperationTextY, defaultCloseOperationWidth,
                defaultCloseOperationHeight);
        Background.add(defaultCloseOperation, new AbsoluteConstraints(defaultCloseOperationTextX, defaultCloseOperationTextY,
                defaultCloseOperationWidth, defaultCloseOperationHeight));
        defaultCloseOperation.setForeground(new java.awt.Color(255, 255, 255));
        defaultCloseOperation.setFont(new java.awt.Font("Tahoma", 1, 16));
        defaultCloseOperation.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        defaultCloseOperation.setText("Frame.DefaultCloseOperation(JFrame.HIDE_ON_CLOSE)");
        defaultCloseOperation.setVisible(true);

        // Hint Declarations.
        final int hintHeight = 40;
        final int hintWidth = 500;
        final int hintTextX = 70;
        final int hintTextY = 210;

        JLabel hint = new JLabel();

        hint.setBounds(hintTextX, hintTextY, hintWidth, hintHeight);
        Background.add(hint, new AbsoluteConstraints(hintTextX, hintTextY, hintWidth, hintHeight));
        hint.setForeground(new java.awt.Color(255, 255, 255));
        hint.setFont(new java.awt.Font("Tahoma", 1, 12));
        hint.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        hint.setText("Hint : Hides the Processes and is still in the Background");
        hint.setVisible(true);

        // HELLO WORLD (JLabel) Declarations.
        final int helloWorldHeight = 38;
        final int helloWorldWidth = 550;
        final int helloWorldLocationX = 20;
        final int helloWorldLocationY = 260;

        JLabel helloWorld = new JLabel();

        final int helloWorldShadowLocationY = 265;

        JLabel helloWorldShadow = new JLabel();

        helloWorld.setBounds(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorld, new AbsoluteConstraints(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight));
        helloWorld.setForeground(new java.awt.Color(255, 208, 0));
        helloWorld.setFont(new java.awt.Font("Iron Shark", 0, 50));

        helloWorldShadow.setBounds(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorldShadow, new AbsoluteConstraints(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight));
        helloWorldShadow.setForeground(new java.awt.Color(0, 0, 0));
        helloWorldShadow.setFont(new java.awt.Font("Iron Shark", 0, 50));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        helloWorld.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorld.setText("Hello World");
        helloWorld.setVisible(true);

        helloWorldShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorldShadow.setText("Hello World");
        helloWorldShadow.setVisible(true);

        // JFrame Visibility
        mainFrame.setVisible(true);
    }

    static void DISPOSEOperation() {

        final int MaxFrameSizeX = 600;
        final int MaxFrameSizeY = 400;

        final int MinFrameSizeX = 600;
        final int MinFrameSizeY = 400;

        JFrame mainFrame = new JFrame();

        // JFrame Size
        mainFrame.setSize(MinFrameSizeX, MinFrameSizeY);
        mainFrame.setMinimumSize(new java.awt.Dimension(MinFrameSizeX, MinFrameSizeY));
        mainFrame.setPreferredSize(new java.awt.Dimension(MaxFrameSizeX, MaxFrameSizeY));
        mainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //JFrame Decoration
        mainFrame.setUndecorated(false);
        mainFrame.setOpacity(1.0f);
        mainFrame.setTitle("COMPROG 3 : Activity 1.3 | JFrame.DISPOSE_ON_CLOSE.");
        mainFrame.setLayout(null);

        // CENTER POPUP MAIN WINDOW
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation(dimension.width / 2 - mainFrame.getWidth() / 2, dimension.height / 2 - mainFrame.getHeight() / 2);

        // JPanel Background 
        final int BackgroundHeigth = 361;
        final int BackgroundWidth = 584;
        final int BackgroundPanelLocationX = 0;
        final int BackgroundPanelLocationY = 0;

        JPanel Background = new JPanel();

        // Background (JPanel) Decorations.
        Background.setBounds(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth);
        mainFrame.add(Background, new AbsoluteConstraints(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth));
        Background.setBackground(new java.awt.Color(0, 0, 32));
        Background.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 200, 0), 2, false));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Logo (JLabel) Declarations.
        final int logoHeight = 158;
        final int logoWidth = 158;
        final int logoLocationX = 5;
        final int logoLocationY = 5;

        JLabel logo = new JLabel();

        // Logo (JLabel) Decorations.
        logo.setBounds(logoLocationX, logoLocationY, logoWidth, logoHeight);
        Background.add(logo, new AbsoluteConstraints(logoLocationX, logoLocationY, logoWidth, logoHeight));
        logo.setForeground(new java.awt.Color(0, 0, 0));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon logoGetter = new ImageIcon("src\\res\\Brion-Tactical-Systems.png");
        Image getLogo = logoGetter.getImage();
        Image scaleLogo = getLogo.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayLogo = new ImageIcon(scaleLogo);
        logo.setIcon(displayLogo);

        // Logo Text (JLabel) Declarations.
        Font IronShark;

        final int companyNameHeight = 20;
        final int companyNameWidth = 600;
        final int companyNameLocationX = 50;
        final int companyNameLocationY = 50;

        JLabel companyName = new JLabel();

        final int cNameShadowLocationY = 54;

        JLabel cNameShadow = new JLabel();

        companyName.setBounds(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight);
        Background.add(companyName, new AbsoluteConstraints(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight));
        companyName.setForeground(new java.awt.Color(255, 208, 0));
        companyName.setFont(new java.awt.Font("Iron Shark", 0, 20));

        cNameShadow.setBounds(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight);
        Background.add(cNameShadow, new AbsoluteConstraints(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight));
        cNameShadow.setForeground(new java.awt.Color(0, 0, 0));
        cNameShadow.setFont(new java.awt.Font("Iron Shark", 0, 20));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        companyName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        companyName.setText("Brion Tactical Systems");
        companyName.setVisible(true);

        cNameShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cNameShadow.setText("Brion Tactical Systems");
        cNameShadow.setVisible(true);

        // Activity Title 
        final int mainTextHeight = 50;
        final int mainTextWidth = 400;
        final int mainTextX = 140;
        final int mainTextY = 60;

        JLabel mainText = new JLabel();

        mainText.setBounds(mainTextX, mainTextY, mainTextWidth, mainTextHeight);
        Background.add(mainText, new AbsoluteConstraints(mainTextX, mainTextY, mainTextWidth, mainTextHeight));
        mainText.setForeground(new java.awt.Color(255, 255, 255));
        mainText.setFont(new java.awt.Font("Tahoma", 1, 20));
        mainText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mainText.setText("JAVA SWING ACTIVITY #1 | GROUP 8");
        mainText.setVisible(true);

        // Students, Sections, Date Declarations.
        final int studentNameHeight = 40;
        final int studentNameWidth = 300;
        final int studentNameTextX = 20;
        final int studentNameTextY = 120;

        JLabel studentName = new JLabel();

        studentName.setBounds(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight);
        Background.add(studentName, new AbsoluteConstraints(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight));
        studentName.setForeground(new java.awt.Color(255, 255, 255));
        studentName.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentName.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentName.setText("Name : Jhon Brix Brion | M");
        studentName.setVisible(true);

        final int studentPairHeight = 40;
        final int studentPairWidth = 300;
        final int studentPairTextX = 20;
        final int studentPairTextY = 140;

        JLabel studentPair = new JLabel();

        studentPair.setBounds(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight);
        Background.add(studentPair, new AbsoluteConstraints(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight));
        studentPair.setForeground(new java.awt.Color(255, 255, 255));
        studentPair.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentPair.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentPair.setText("Pair : Shane Marie Mon | F");
        studentPair.setVisible(true);

        final int dateCreatedHeight = 40;
        final int dateCreatedWidth = 300;
        final int dateCreatedTextX = 310;
        final int dateCreatedTextY = 120;

        JLabel dateCreated = new JLabel();

        dateCreated.setBounds(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight);
        Background.add(dateCreated, new AbsoluteConstraints(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight));
        dateCreated.setForeground(new java.awt.Color(255, 255, 255));
        dateCreated.setFont(new java.awt.Font("Tahoma", 1, 16));
        dateCreated.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        dateCreated.setText("Date Created : February 4 2022");
        dateCreated.setVisible(true);

        final int subjectHeight = 40;
        final int subjectWidth = 300;
        final int subjectTextX = 310;
        final int subjectTextY = 140;

        JLabel subject = new JLabel();

        subject.setBounds(subjectTextX, subjectTextY, subjectWidth, subjectHeight);
        Background.add(subject, new AbsoluteConstraints(subjectTextX, subjectTextY, subjectWidth, subjectHeight));
        subject.setForeground(new java.awt.Color(255, 255, 255));
        subject.setFont(new java.awt.Font("Tahoma", 1, 16));
        subject.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        subject.setText("Subject : COMPROG 3");
        subject.setVisible(true);

        // Default Close Operation Label Declarations.
        final int defaultCloseOperationHeight = 40;
        final int defaultCloseOperationWidth = 500;
        final int defaultCloseOperationTextX = 70;
        final int defaultCloseOperationTextY = 190;

        JLabel defaultCloseOperation = new JLabel();

        defaultCloseOperation.setBounds(defaultCloseOperationTextX, defaultCloseOperationTextY, defaultCloseOperationWidth,
                defaultCloseOperationHeight);
        Background.add(defaultCloseOperation, new AbsoluteConstraints(defaultCloseOperationTextX, defaultCloseOperationTextY,
                defaultCloseOperationWidth, defaultCloseOperationHeight));
        defaultCloseOperation.setForeground(new java.awt.Color(255, 255, 255));
        defaultCloseOperation.setFont(new java.awt.Font("Tahoma", 1, 16));
        defaultCloseOperation.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        defaultCloseOperation.setText("Frame.DefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE)");
        defaultCloseOperation.setVisible(true);

        // Hint Declarations.
        final int hintHeight = 40;
        final int hintWidth = 500;
        final int hintTextX = 70;
        final int hintTextY = 210;

        JLabel hint = new JLabel();

        hint.setBounds(hintTextX, hintTextY, hintWidth, hintHeight);
        Background.add(hint, new AbsoluteConstraints(hintTextX, hintTextY, hintWidth, hintHeight));
        hint.setForeground(new java.awt.Color(255, 255, 255));
        hint.setFont(new java.awt.Font("Tahoma", 1, 12));
        hint.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        hint.setText("Hint : Closes a single process (JFrame), leaving other processes running.");
        hint.setVisible(true);

        // HELLO WORLD (JLabel) Declarations.
        final int helloWorldHeight = 38;
        final int helloWorldWidth = 550;
        final int helloWorldLocationX = 20;
        final int helloWorldLocationY = 260;

        JLabel helloWorld = new JLabel();

        final int helloWorldShadowLocationY = 265;

        JLabel helloWorldShadow = new JLabel();

        helloWorld.setBounds(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorld, new AbsoluteConstraints(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight));
        helloWorld.setForeground(new java.awt.Color(255, 208, 0));
        helloWorld.setFont(new java.awt.Font("Iron Shark", 0, 50));

        helloWorldShadow.setBounds(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorldShadow, new AbsoluteConstraints(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight));
        helloWorldShadow.setForeground(new java.awt.Color(0, 0, 0));
        helloWorldShadow.setFont(new java.awt.Font("Iron Shark", 0, 50));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        helloWorld.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorld.setText("Hello World");
        helloWorld.setVisible(true);

        helloWorldShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorldShadow.setText("Hello World");
        helloWorldShadow.setVisible(true);

        // JFrame Visibility
        mainFrame.setVisible(true);
    }

    static void DoNothingOperation() {

        final int MaxFrameSizeX = 600;
        final int MaxFrameSizeY = 400;

        final int MinFrameSizeX = 600;
        final int MinFrameSizeY = 400;

        JFrame mainFrame = new JFrame();

        // JFrame Size
        mainFrame.setSize(MinFrameSizeX, MinFrameSizeY);
        mainFrame.setMinimumSize(new java.awt.Dimension(MinFrameSizeX, MinFrameSizeY));
        mainFrame.setPreferredSize(new java.awt.Dimension(MaxFrameSizeX, MaxFrameSizeY));
        mainFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        //JFrame Decoration
        mainFrame.setUndecorated(false);
        mainFrame.setOpacity(1.0f);
        mainFrame.setTitle("COMPROG 3 : Activity 1.4 | JFrame.DO_NOTHING_ON_CLOSE.");
        mainFrame.setLayout(null);

        // CENTER POPUP MAIN WINDOW
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation(dimension.width / 2 - mainFrame.getWidth() / 2, dimension.height / 2 - mainFrame.getHeight() / 2);

        // JPanel Background 
        final int BackgroundHeigth = 361;
        final int BackgroundWidth = 584;
        final int BackgroundPanelLocationX = 0;
        final int BackgroundPanelLocationY = 0;

        JPanel Background = new JPanel();

        // Background (JPanel) Decorations.
        Background.setBounds(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth);
        mainFrame.add(Background, new AbsoluteConstraints(BackgroundPanelLocationX, BackgroundPanelLocationY, BackgroundWidth, BackgroundHeigth));
        Background.setBackground(new java.awt.Color(0, 0, 32));
        Background.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 200, 0), 2, false));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        // Logo (JLabel) Declarations.
        final int logoHeight = 158;
        final int logoWidth = 158;
        final int logoLocationX = 5;
        final int logoLocationY = 5;

        JLabel logo = new JLabel();

        // Logo (JLabel) Decorations.
        logo.setBounds(logoLocationX, logoLocationY, logoWidth, logoHeight);
        Background.add(logo, new AbsoluteConstraints(logoLocationX, logoLocationY, logoWidth, logoHeight));
        logo.setForeground(new java.awt.Color(0, 0, 0));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageIcon logoGetter = new ImageIcon("src\\res\\Brion-Tactical-Systems.png");
        Image getLogo = logoGetter.getImage();
        Image scaleLogo = getLogo.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon displayLogo = new ImageIcon(scaleLogo);
        logo.setIcon(displayLogo);

        // Logo Text (JLabel) Declarations.
        Font IronShark;

        final int companyNameHeight = 20;
        final int companyNameWidth = 600;
        final int companyNameLocationX = 50;
        final int companyNameLocationY = 50;

        JLabel companyName = new JLabel();

        final int cNameShadowLocationY = 54;

        JLabel cNameShadow = new JLabel();

        companyName.setBounds(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight);
        Background.add(companyName, new AbsoluteConstraints(companyNameLocationX, companyNameLocationY, companyNameWidth, companyNameHeight));
        companyName.setForeground(new java.awt.Color(255, 208, 0));
        companyName.setFont(new java.awt.Font("Iron Shark", 0, 20));

        cNameShadow.setBounds(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight);
        Background.add(cNameShadow, new AbsoluteConstraints(companyNameLocationX, cNameShadowLocationY, companyNameWidth, companyNameHeight));
        cNameShadow.setForeground(new java.awt.Color(0, 0, 0));
        cNameShadow.setFont(new java.awt.Font("Iron Shark", 0, 20));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        companyName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        companyName.setText("Brion Tactical Systems");
        companyName.setVisible(true);

        cNameShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cNameShadow.setText("Brion Tactical Systems");
        cNameShadow.setVisible(true);

        // Activity Title 
        final int mainTextHeight = 50;
        final int mainTextWidth = 400;
        final int mainTextX = 140;
        final int mainTextY = 60;

        JLabel mainText = new JLabel();

        mainText.setBounds(mainTextX, mainTextY, mainTextWidth, mainTextHeight);
        Background.add(mainText, new AbsoluteConstraints(mainTextX, mainTextY, mainTextWidth, mainTextHeight));
        mainText.setForeground(new java.awt.Color(255, 255, 255));
        mainText.setFont(new java.awt.Font("Tahoma", 1, 20));
        mainText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mainText.setText("JAVA SWING ACTIVITY #1 | GROUP 8");
        mainText.setVisible(true);

        // Students, Sections, Date Declarations.
        final int studentNameHeight = 40;
        final int studentNameWidth = 300;
        final int studentNameTextX = 20;
        final int studentNameTextY = 120;

        JLabel studentName = new JLabel();

        studentName.setBounds(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight);
        Background.add(studentName, new AbsoluteConstraints(studentNameTextX, studentNameTextY, studentNameWidth, studentNameHeight));
        studentName.setForeground(new java.awt.Color(255, 255, 255));
        studentName.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentName.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentName.setText("Name : Jhon Brix Brion | M");
        studentName.setVisible(true);

        final int studentPairHeight = 40;
        final int studentPairWidth = 300;
        final int studentPairTextX = 20;
        final int studentPairTextY = 140;

        JLabel studentPair = new JLabel();

        studentPair.setBounds(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight);
        Background.add(studentPair, new AbsoluteConstraints(studentPairTextX, studentPairTextY, studentPairWidth, studentPairHeight));
        studentPair.setForeground(new java.awt.Color(255, 255, 255));
        studentPair.setFont(new java.awt.Font("Tahoma", 1, 16));
        studentPair.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        studentPair.setText("Pair : Shane Marie Mon | F");
        studentPair.setVisible(true);

        final int dateCreatedHeight = 40;
        final int dateCreatedWidth = 300;
        final int dateCreatedTextX = 310;
        final int dateCreatedTextY = 120;

        JLabel dateCreated = new JLabel();

        dateCreated.setBounds(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight);
        Background.add(dateCreated, new AbsoluteConstraints(dateCreatedTextX, dateCreatedTextY, dateCreatedWidth, dateCreatedHeight));
        dateCreated.setForeground(new java.awt.Color(255, 255, 255));
        dateCreated.setFont(new java.awt.Font("Tahoma", 1, 16));
        dateCreated.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        dateCreated.setText("Date Created : February 4 2022");
        dateCreated.setVisible(true);

        final int subjectHeight = 40;
        final int subjectWidth = 300;
        final int subjectTextX = 310;
        final int subjectTextY = 140;

        JLabel subject = new JLabel();

        subject.setBounds(subjectTextX, subjectTextY, subjectWidth, subjectHeight);
        Background.add(subject, new AbsoluteConstraints(subjectTextX, subjectTextY, subjectWidth, subjectHeight));
        subject.setForeground(new java.awt.Color(255, 255, 255));
        subject.setFont(new java.awt.Font("Tahoma", 1, 16));
        subject.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        subject.setText("Subject : COMPROG 3");
        subject.setVisible(true);

        // Default Close Operation Label Declarations.
        final int defaultCloseOperationHeight = 40;
        final int defaultCloseOperationWidth = 500;
        final int defaultCloseOperationTextX = 70;
        final int defaultCloseOperationTextY = 190;

        JLabel defaultCloseOperation = new JLabel();

        defaultCloseOperation.setBounds(defaultCloseOperationTextX, defaultCloseOperationTextY, defaultCloseOperationWidth,
                defaultCloseOperationHeight);
        Background.add(defaultCloseOperation, new AbsoluteConstraints(defaultCloseOperationTextX, defaultCloseOperationTextY,
                defaultCloseOperationWidth, defaultCloseOperationHeight));
        defaultCloseOperation.setForeground(new java.awt.Color(255, 255, 255));
        defaultCloseOperation.setFont(new java.awt.Font("Tahoma", 1, 14));
        defaultCloseOperation.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        defaultCloseOperation.setText("Frame.DefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE)");
        defaultCloseOperation.setVisible(true);

        // Hint Declarations.
        final int hintHeight = 40;
        final int hintWidth = 500;
        final int hintTextX = 70;
        final int hintTextY = 210;

        JLabel hint = new JLabel();

        hint.setBounds(hintTextX, hintTextY, hintWidth, hintHeight);
        Background.add(hint, new AbsoluteConstraints(hintTextX, hintTextY, hintWidth, hintHeight));
        hint.setForeground(new java.awt.Color(255, 255, 255));
        hint.setFont(new java.awt.Font("Tahoma", 1, 12));
        hint.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        hint.setText("Hint : Does not do anything when the exit button is pressed.");
        hint.setVisible(true);

        // HELLO WORLD (JLabel) Declarations.
        final int helloWorldHeight = 38;
        final int helloWorldWidth = 550;
        final int helloWorldLocationX = 20;
        final int helloWorldLocationY = 260;

        JLabel helloWorld = new JLabel();

        final int helloWorldShadowLocationY = 265;

        JLabel helloWorldShadow = new JLabel();

        helloWorld.setBounds(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorld, new AbsoluteConstraints(helloWorldLocationX, helloWorldLocationY, helloWorldWidth, helloWorldHeight));
        helloWorld.setForeground(new java.awt.Color(255, 208, 0));
        helloWorld.setFont(new java.awt.Font("Iron Shark", 0, 50));

        helloWorldShadow.setBounds(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight);
        Background.add(helloWorldShadow, new AbsoluteConstraints(helloWorldLocationX, helloWorldShadowLocationY, helloWorldWidth, helloWorldHeight));
        helloWorldShadow.setForeground(new java.awt.Color(0, 0, 0));
        helloWorldShadow.setFont(new java.awt.Font("Iron Shark", 0, 50));

        try {

            IronShark = Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")).deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\res\\Iron-Shark.ttf")));

        } catch (IOException | FontFormatException e) {

        }

        helloWorld.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorld.setText("Hello World");
        helloWorld.setVisible(true);

        helloWorldShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        helloWorldShadow.setText("Hello World");
        helloWorldShadow.setVisible(true);

        // JFrame Visibility
        mainFrame.setVisible(true);
    }

    public static void main(String[] args) {
        exitOperation(); // CLOSES ALL PROCESSES (JFrames) RUNNING IN THE BACKGROUND (MEMORY).
        HIDEOperation(); // CLOSES ALL PROCESSES, BUT THE PROGRAM IS STILL RUNNING IN THE BACKGROUND (MEMORY)
        DISPOSEOperation(); // CLOSES A SINGLE PROCES (JFrame), BUT NOT ALL PROCESSES (JFrames).
        DoNothingOperation(); // DOES NOT DO ANYTHING WHEN EXIT BUTTON IS PRESSED.

    }

}
