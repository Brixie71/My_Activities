package jswingact3;

import java.awt.HeadlessException;
import javax.swing.JOptionPane;



public class JSwingAct3 {
    
    static void Calculator(){
        
        String message = "This is a Calculator Program using JOptionPane.\n"
                       + "Name : BRION, JHON BRIX G.\n"
                       + "Pair : MON, SHANE MARIE\n"
                       + "Year and Section : 2nd Year - BSCS 2B.";
        
        String title = "Java Swing Activity 3 : JOptionPane Calulator";
        
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.PLAIN_MESSAGE);

            String inputNumOne = "Enter First Number : ";

            String InputOne = JOptionPane.showInputDialog(null, inputNumOne, title,JOptionPane.INFORMATION_MESSAGE);

            if(InputOne.equals(JOptionPane.CANCEL_OPTION)){ 
                    System.exit(0);
            }

            long Num1 = Integer.parseInt(InputOne);

            String[] operators = new String[] {"Addition","Subtraction","Multiplication", "Division", "Cancel"};

            String operationInstruction = "Choose an Operation :";

            int opt = JOptionPane.showOptionDialog(null, operationInstruction, title, JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, operators, operators[0]);

            if(4==opt){
                    System.exit(0);
            }

            String inputNumTwo = "Enter Second Number : ";

            String InputTwo = JOptionPane.showInputDialog(null, inputNumTwo, title,JOptionPane.INFORMATION_MESSAGE);

            if(InputTwo.equals(JOptionPane.CANCEL_OPTION)){
                    System.exit(0);

            }

            long Num2 = Integer.parseInt(InputTwo);

            long AddResult = Num1 + Num2;

            long SubResult = Num1 - Num2;

            long MulResult = Num1 * Num2;

            long DivResult = Num1 / Num2;

            if(0==opt) {

                JOptionPane.showMessageDialog(null, +Num1 +" + " +Num2 +" = " + AddResult, title, JOptionPane.INFORMATION_MESSAGE);

             } else if(1==opt) {

                JOptionPane.showMessageDialog(null, +Num1 +" - " +Num2 +" = " + SubResult, title, JOptionPane.INFORMATION_MESSAGE);

             }  else if(2==opt) {

                JOptionPane.showMessageDialog(null, +Num1 +" * " +Num2 +" = " + MulResult, title, JOptionPane.INFORMATION_MESSAGE);

             } else if(3==opt){

                JOptionPane.showMessageDialog(null, +Num1 +" / " +Num2 +" = " + DivResult, title, JOptionPane.INFORMATION_MESSAGE);

             } 
                
                
                
            

    }

    public static void main(String[] args) {
        
        /* Set the Nimbus look and feel */

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JSwingAct3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>
        
        Calculator();
        
 
    }
    
}
